# Miniature Paint Recipes

A WordPress plugin that treats miniature painting workflows like recipe cards: structured paints, mixes, techniques, and steps, rendered as a reusable card.

## Features

- CPT: `mpr_paint_recipe`
- Meta editor: subject, scale, paints, steps
- Front-end card template + print template
- JSON-LD HowTo schema output
- Shortcode: `[paint_recipe id="123"]`
- Dynamic Gutenberg block: `mpr/paint-recipe`
- Tools: export/import JSON + cache purge
- Extension hook: `do_action('mpr_init')`
- Migration scaffold (DB version option)

## Usage

- Create a Paint Recipe.
- Insert in any post/page using the block, or via shortcode:
  - `[paint_recipe id="123"]`

## 1.8.1.2 changes

I have removed the automatic size multiplier from the calculator. The recipe's recorded paint amounts are now the baseline for its recorded batch size. Changing **Models to paint** scales that same miniature type proportionally. Existing profile metadata is retained for backwards compatibility, but no longer changes quantities.

The displayed 12 ml pot equivalents are estimates, not an instruction to buy that number of pots. Paint viscosity, thinning, wastage and coverage vary. Draft and private recipe cards require read permission even when embedded by ID.
