/* global wp */
(function () {
	const { registerBlockType } = wp.blocks;
	const { __ } = wp.i18n;
	const { PanelBody, ComboboxControl, ToggleControl, Spinner } = wp.components;
	const { InspectorControls } = wp.blockEditor;
	const { useEffect, useState } = wp.element;
	const apiFetch = wp.apiFetch;
	const ServerSideRender = wp.serverSideRender;

	registerBlockType('mpr/paint-recipe', {
		edit: function (props) {
			const { attributes, setAttributes } = props;
			const [options, setOptions] = useState([]);
			const [loading, setLoading] = useState(false);
			const [search, setSearch] = useState('');

			useEffect(function () {
				let mounted = true;
				setLoading(true);
				apiFetch({ path: '/wp/v2/mpr_paint_recipe?per_page=20&search=' + encodeURIComponent(search || '') + '&_fields=id,title' })
					.then(function (posts) {
						if (!mounted) return;
						setOptions((posts || []).map(function (post) {
							return { value: String(post.id), label: post.title && post.title.rendered ? post.title.rendered : ('#' + post.id) };
						}));
					})
					.catch(function () {
						if (!mounted) return;
						setOptions([]);
					})
					.finally(function () {
						if (mounted) setLoading(false);
					});
				return function () { mounted = false; };
			}, [search]);

			return wp.element.createElement(
				wp.element.Fragment,
				null,
				wp.element.createElement(
					InspectorControls,
					null,
					wp.element.createElement(
						PanelBody,
						{ title: __('Paint Recipe Card', 'miniature-paint-recipes') },
						loading ? wp.element.createElement(Spinner, null) : null,
						wp.element.createElement(ComboboxControl, {
							label: __('Recipe', 'miniature-paint-recipes'),
							value: attributes.id ? String(attributes.id) : '',
							onFilterValueChange: function (value) { setSearch(value || ''); },
							options: options,
							onChange: function (value) { setAttributes({ id: parseInt(value || '0', 10) || 0 }); },
							help: __('Search paint recipe posts by title.', 'miniature-paint-recipes')
						}),
						wp.element.createElement(ToggleControl, {
							label: __('Print Layout', 'miniature-paint-recipes'),
							checked: !!attributes.print,
							onChange: function (v) { setAttributes({ print: !!v }); }
						})
					)
				),
				wp.element.createElement(ServerSideRender, { block: 'mpr/paint-recipe', attributes: attributes })
			);
		},
		save: function () { return null; }
	});
})();
