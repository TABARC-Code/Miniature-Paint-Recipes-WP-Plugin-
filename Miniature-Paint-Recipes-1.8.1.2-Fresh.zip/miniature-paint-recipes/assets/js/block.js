/* global wp */
(function () {
	const { registerBlockType } = wp.blocks;
	const { __ } = wp.i18n;
	const { PanelBody, ComboboxControl, ToggleControl, TextControl, Spinner } = wp.components;
	const { InspectorControls } = wp.blockEditor;
	const { useEffect, useState, createElement, Fragment } = wp.element;
	const apiFetch = wp.apiFetch;
	const ServerSideRender = wp.serverSideRender;

	// REST titles arrive as HTML (entities such as &amp;), so turn them back into plain text.
	function decodeEntities(html) {
		const box = document.createElement('textarea');
		box.innerHTML = html;
		return box.value;
	}

	function recipeLabel(post) {
		return post.title && post.title.rendered ? decodeEntities(post.title.rendered) : ('#' + post.id);
	}

	// Recipe search for the picker. The chosen recipe is fetched by ID too, so its title shows even when it is not in the search results.
	function useRecipeOptions(selectedId) {
		const [options, setOptions] = useState([]);
		const [selected, setSelected] = useState(null);
		const [loading, setLoading] = useState(false);
		const [search, setSearch] = useState('');

		useEffect(function () {
			let mounted = true;
			setLoading(true);
			apiFetch({ path: '/wp/v2/mpr_paint_recipe?per_page=20&search=' + encodeURIComponent(search || '') + '&_fields=id,title' })
				.then(function (posts) {
					if (!mounted) return;
					setOptions((posts || []).map(function (post) { return { value: String(post.id), label: recipeLabel(post) }; }));
				})
				.catch(function () { if (mounted) setOptions([]); })
				.finally(function () { if (mounted) setLoading(false); });
			return function () { mounted = false; };
		}, [search]);

		useEffect(function () {
			if (!selectedId) { setSelected(null); return undefined; }
			let mounted = true;
			apiFetch({ path: '/wp/v2/mpr_paint_recipe/' + selectedId + '?_fields=id,title' })
				.then(function (post) { if (mounted && post) setSelected({ value: String(post.id), label: recipeLabel(post) }); })
				.catch(function () { /* the recipe may have been deleted: leave the picker empty */ });
			return function () { mounted = false; };
		}, [selectedId]);

		const known = selected && !options.some(function (o) { return o.value === selected.value; });
		return { options: known ? [selected].concat(options) : options, loading: loading, setSearch: setSearch };
	}

	function RecipePicker(props) {
		const found = useRecipeOptions(props.value);
		return createElement(
			Fragment,
			null,
			found.loading ? createElement(Spinner, null) : null,
			createElement(ComboboxControl, {
				label: __('Recipe', 'miniature-paint-recipes'),
				value: props.value ? String(props.value) : '',
				onFilterValueChange: function (value) { found.setSearch(value || ''); },
				options: found.options,
				onChange: function (value) { props.onChange(parseInt(value || '0', 10) || 0); },
				help: __('Search paint recipe posts by title.', 'miniature-paint-recipes')
			})
		);
	}

	registerBlockType('mpr/paint-recipe', {
		edit: function (props) {
			const { attributes, setAttributes } = props;
			return createElement(
				Fragment,
				null,
				createElement(
					InspectorControls,
					null,
					createElement(
						PanelBody,
						{ title: __('Paint Recipe Card', 'miniature-paint-recipes') },
						createElement(RecipePicker, { value: attributes.id, onChange: function (id) { setAttributes({ id: id }); } }),
						createElement(ToggleControl, {
							label: __('Print Layout', 'miniature-paint-recipes'),
							checked: !!attributes.print,
							onChange: function (v) { setAttributes({ print: !!v }); }
						})
					)
				),
				createElement(ServerSideRender, { block: 'mpr/paint-recipe', attributes: attributes })
			);
		},
		save: function () { return null; }
	});

	registerBlockType('mpr/paint-recipe-link', {
		edit: function (props) {
			const { attributes, setAttributes } = props;
			return createElement(
				Fragment,
				null,
				createElement(
					InspectorControls,
					null,
					createElement(
						PanelBody,
						{ title: __('Link Card', 'miniature-paint-recipes') },
						createElement(RecipePicker, { value: attributes.id, onChange: function (id) { setAttributes({ id: id }); } }),
						createElement(TextControl, {
							label: __('Button text', 'miniature-paint-recipes'),
							value: attributes.text || '',
							placeholder: __('View recipe', 'miniature-paint-recipes'),
							onChange: function (v) { setAttributes({ text: v || '' }); }
						}),
						createElement(ToggleControl, {
							label: __('Show image', 'miniature-paint-recipes'),
							checked: !!attributes.image,
							onChange: function (v) { setAttributes({ image: !!v }); }
						})
					)
				),
				createElement(ServerSideRender, { block: 'mpr/paint-recipe-link', attributes: attributes })
			);
		},
		save: function () { return null; }
	});
})();
