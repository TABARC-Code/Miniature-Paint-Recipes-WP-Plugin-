(function ($) {
	'use strict';

	function uuid4() {
		if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
		return 'mpr-' + Date.now() + '-' + Math.floor(Math.random() * 1000000);
	}

	function readRepeater($wrap) {
		const out = [];
		$wrap.find('.mpr-item').each(function () {
			const row = {};
			$(this).find('.mpr-field').each(function () {
				const key = $(this).data('field');
				if (!key) return;
				row[key] = $(this).val();
			});
			out.push(row);
		});
		return out;
	}

	function writeHidden() {
		$('.mpr-step').each(function () {
			const values = $(this).find('.mpr-step-paints-select').val() || [];
			$(this).find('input.mpr-field[data-field="paints_used_json"]').val(JSON.stringify(values));
		});
		$('#mpr-paints-json').val(JSON.stringify(readRepeater($('#mpr-paints'))));
		$('#mpr-steps-json').val(JSON.stringify(readRepeater($('#mpr-steps'))));
	}

	function nextIndex($wrap) {
		const last = $wrap.find('.mpr-item').last();
		if (!last.length) return 0;
		const idx = parseInt(last.data('index'), 10);
		return Number.isNaN(idx) ? 0 : idx + 1;
	}

	function currentPaintOptions() {
		const options = [];
		$('#mpr-paints .mpr-paint').each(function () {
			const id = $(this).find('input.mpr-field[data-field="id"]').val() || '';
			if (!id) return;
			const brand = $(this).find('input.mpr-field[data-field="brand"]').val() || '';
			const name = $(this).find('input.mpr-field[data-field="name"]').val() || '';
			const role = $(this).find('input.mpr-field[data-field="role"]').val() || '';
			const label = [role ? '[' + role + ']' : '', brand, name].filter(Boolean).join(' ').trim() || id;
			options.push({ id, label });
		});
		return options;
	}

	function syncStepPaintSelects() {
		const options = currentPaintOptions();
		$('.mpr-step-paints-select').each(function () {
			const $select = $(this);
			const selected = $select.val() || [];
			$select.empty();
			options.forEach(function (opt) {
				const $option = $('<option></option>').val(opt.id).text(opt.label);
				if (selected.indexOf(opt.id) !== -1) $option.prop('selected', true);
				$select.append($option);
			});
		});
	}

	function paintTemplate(idx) {
		return (
			'<div class="mpr-item mpr-paint" data-index="' + idx + '" data-paint-id="' + uuid4() + '">' +
				'<div class="mpr-grid">' +
					'<input type="hidden" class="mpr-field" data-field="id" value="' + uuid4() + '" />' +
					'<div class="mpr-paint-linker mpr-wide">' +
						'<input type="text" class="mpr-field" data-field="library_id" value="" placeholder="Linked library paint ID (optional)" />' +
						'<button type="button" class="button mpr-link-paint">Find in library</button>' +
						'<span class="description">Optional, but it unlocks equivalents and keeps names sane.</span>' +
					'</div>' +
					'<input type="text" class="mpr-field" data-field="role" placeholder="role (primer/base/shade/highlight/varnish/effect)" />' +
					'<input type="text" class="mpr-field" data-field="brand" placeholder="brand" />' +
					'<input type="text" class="mpr-field" data-field="range" placeholder="range" />' +
					'<input type="text" class="mpr-field" data-field="name" placeholder="paint name" />' +
					'<input type="text" class="mpr-field" data-field="code" placeholder="code (optional)" />' +
					'<input type="text" class="mpr-field mpr-hex" data-field="hex" placeholder="#rrggbb (optional)" />' +
					'<input type="text" class="mpr-field" data-field="mix" placeholder="mix / thinning notes" />' +
					'<input type="text" class="mpr-field mpr-wide" data-field="notes" placeholder="notes (coverage, substitute, finish)" />' +
					'<input type="number" min="0" step="0.01" class="mpr-field" data-field="calc_amount" placeholder="calc amount per model" />' +
					'<select class="mpr-field" data-field="calc_unit">' +
						'<option value="drops">Drops</option>' +
						'<option value="ml">Ml</option>' +
						'<option value="pots">Pots</option>' +
						'<option value="cans">Cans</option>' +
					'</select>' +
				'</div>' +
				'<button type="button" class="button-link mpr-remove">' + (mprAdmin?.strings?.remove || 'Remove') + '</button>' +
			'</div>'
		);
	}

	function stepTemplate(idx) {
		return (
			'<div class="mpr-item mpr-step" data-index="' + idx + '">' +
				'<div class="mpr-grid">' +
					'<input type="text" class="mpr-field" data-field="group" placeholder="group (Prep, Base, Wash, Finish…)" />' +
					'<input type="text" class="mpr-field mpr-wide" data-field="title" placeholder="step title" />' +
					'<textarea class="mpr-field mpr-wide" data-field="body" rows="3" placeholder="what you actually did"></textarea>' +
					'<input type="text" class="mpr-field" data-field="paints" placeholder="legacy paint text (optional)" />' +
					'<input type="hidden" class="mpr-field" data-field="paints_used_json" value="[]" />' +
					'<div class="mpr-step-paints mpr-wide">' +
						'<label><strong>Linked paints used</strong></label>' +
						'<select class="mpr-step-paints-select" multiple size="4"></select>' +
						'<span class="description">Hold Ctrl/Cmd to select more than one.</span>' +
					'</div>' +
					'<input type="text" class="mpr-field" data-field="techniques" placeholder="techniques (comma list)" />' +
					'<input type="text" class="mpr-field" data-field="time" placeholder="time (optional)" />' +
					'<div class="mpr-media" data-mpr-media="1">' +
						'<input type="hidden" class="mpr-field" data-field="media_id" value="" />' +
						'<div class="mpr-media__preview"><span class="mpr-media__empty">No step image</span></div>' +
						'<button type="button" class="button mpr-media-select">' + (mprAdmin?.strings?.select_image || 'Select image') + '</button>' +
						'<button type="button" class="button mpr-media-remove">' + (mprAdmin?.strings?.remove_image || 'Remove image') + '</button>' +
					'</div>' +
				'</div>' +
				'<button type="button" class="button-link mpr-remove">' + (mprAdmin?.strings?.remove || 'Remove') + '</button>' +
			'</div>'
		);
	}

	let mprMediaFrame = null;
	let mprMediaTarget = null;

	function setMedia($wrap, attachment) {
		const id = attachment && attachment.id ? String(attachment.id) : '';
		$wrap.find('input.mpr-field[data-field="media_id"]').val(id);
		const url = attachment && attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : (attachment && attachment.url ? attachment.url : '');
		if (url) {
			$wrap.find('.mpr-media__preview').html('<img class="mpr-media__img" src="' + url + '" alt="" />');
		} else {
			$wrap.find('.mpr-media__preview').html('<span class="mpr-media__empty">No step image</span>');
		}
		writeHidden();
	}

	$(document).on('click', '.mpr-add-paint', function () {
		const $wrap = $('#mpr-paints');
		$wrap.append(paintTemplate(nextIndex($wrap)));
		syncStepPaintSelects();
		writeHidden();
	});

	$(document).on('click', '.mpr-add-step', function () {
		const $wrap = $('#mpr-steps');
		$wrap.append(stepTemplate(nextIndex($wrap)));
		syncStepPaintSelects();
		writeHidden();
	});

	$(document).on('click', '.mpr-media-select', function (e) {
		e.preventDefault();
		mprMediaTarget = $(this).closest('.mpr-media');
		if (!window.wp || !wp.media) return;
		if (!mprMediaFrame) {
			mprMediaFrame = wp.media({
				title: (mprAdmin?.strings?.select_image || 'Select image'),
				button: { text: (mprAdmin?.strings?.select_image || 'Select image') },
				multiple: false,
				library: { type: 'image' }
			});
			mprMediaFrame.on('select', function () {
				const selection = mprMediaFrame.state().get('selection');
				const attachment = selection && selection.first ? selection.first().toJSON() : null;
				if (mprMediaTarget) setMedia(mprMediaTarget, attachment);
			});
		}
		mprMediaFrame.open();
	});

	$(document).on('click', '.mpr-media-remove', function (e) {
		e.preventDefault();
		const $wrap = $(this).closest('.mpr-media');
		$wrap.find('input.mpr-field[data-field="media_id"]').val('');
		$wrap.find('.mpr-media__preview').html('<span class="mpr-media__empty">No step image</span>');
		writeHidden();
	});

	$(document).on('click', '.mpr-link-paint', async function (e) {
		e.preventDefault();
		const $paint = $(this).closest('.mpr-paint');
		const q = window.prompt('Search Paint Library (title)', '');
		if (q === null) return;
		const base = (window.mprAdmin && window.mprAdmin.restUrl) ? window.mprAdmin.restUrl : '/wp-json/';
		const url = base.replace(/\/$/, '') + '/mpr/v1/paints?q=' + encodeURIComponent(q) + '&per_page=10';
		let results = [];
		try {
			const res = await fetch(url, { credentials: 'same-origin' });
			results = await res.json();
		} catch (err) {
			window.alert('Paint search failed.');
			return;
		}
		if (!Array.isArray(results) || results.length === 0) {
			window.alert('No paints found.');
			return;
		}
		let menu = 'Pick a paint:\n';
		results.forEach(function (p, i) {
			menu += (i + 1) + ') ' + [p.brand || '', p.range || '', p.title || ''].filter(Boolean).join(' ') + ' (ID ' + p.id + ')\n';
		});
		const choice = window.prompt(menu, '1');
		if (choice === null) return;
		const idx = parseInt(choice, 10) - 1;
		if (Number.isNaN(idx) || idx < 0 || idx >= results.length) {
			window.alert('Invalid choice.');
			return;
		}
		const chosen = results[idx];
		$paint.find('input.mpr-field[data-field="library_id"]').val(String(chosen.id));
		if (chosen.brand) $paint.find('input.mpr-field[data-field="brand"]').val(chosen.brand);
		if (chosen.range) $paint.find('input.mpr-field[data-field="range"]').val(chosen.range);
		if (chosen.title) $paint.find('input.mpr-field[data-field="name"]').val(chosen.title);
		if (chosen.code) $paint.find('input.mpr-field[data-field="code"]').val(chosen.code);
		if (chosen.hex) $paint.find('input.mpr-field[data-field="hex"]').val(chosen.hex);
		syncStepPaintSelects();
		writeHidden();
	});

	$(document).on('input', '#mpr-paint-filter', function () {
		const q = ($(this).val() || '').toLowerCase();
		$('#mpr-paints .mpr-paint').each(function () {
			const text = ($(this).text() + ' ' + $(this).find('input').map(function () { return $(this).val(); }).get().join(' ')).toLowerCase();
			$(this).toggle(text.indexOf(q) !== -1);
		});
	});

	$(document).on('click', '.mpr-filter-clear', function () {
		$('#mpr-paint-filter').val('').trigger('input');
	});

	$(document).on('change', '.mpr-step-paints-select', writeHidden);

	$(document).on('click', '.mpr-remove', function () {
		const $item = $(this).closest('.mpr-item');
		const isPaint = $item.hasClass('mpr-paint');
		$item.remove();
		if (isPaint) syncStepPaintSelects();
		writeHidden();
	});

	$(document).on('input change', '.mpr-field', function () {
		if ($(this).closest('.mpr-paint').length) {
			syncStepPaintSelects();
		}
		writeHidden();
	});

	$(function () {
		syncStepPaintSelects();
		writeHidden();
	});
})(jQuery);
