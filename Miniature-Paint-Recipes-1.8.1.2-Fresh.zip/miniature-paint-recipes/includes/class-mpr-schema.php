<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Schema {
	public function build_howto_schema( \WP_Post $post, string $subject, string $scale, array $paints, array $steps ): array {
		$name = (string) get_the_title( $post );
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_strip_all_tags( (string) $post->post_content );
		$desc = trim( (string) $desc );

		$supply = array();
		foreach ( $paints as $p ) {
			if ( ! is_array( $p ) ) { continue; }
			$brand = trim( (string) ( $p['brand'] ?? '' ) );
			$namep = trim( (string) ( $p['name'] ?? '' ) );
			if ( '' === $brand && '' === $namep ) { continue; }
			$label = trim( implode( ' ', array_filter( array( $brand, $namep ) ) ) );
			$supply[] = array( '@type' => 'HowToSupply', 'name' => $label );
		}

		$howto_steps = array();
		$pos = 1;
		foreach ( $steps as $s ) {
			if ( ! is_array( $s ) ) { continue; }
			$title = trim( (string) ( $s['title'] ?? '' ) );
			$body  = trim( (string) ( $s['body'] ?? '' ) );
			$group = trim( (string) ( $s['group'] ?? '' ) );
			if ( '' === $title && '' === $body && '' === $group ) { continue; }
			$text = trim( implode( ' — ', array_filter( array( $group, $body ) ) ) );
			$step = array(
				'@type' => 'HowToStep',
				'position' => $pos,
				'name' => $title !== '' ? $title : sprintf( 'Step %d', $pos ),
				'text' => $text,
			);
			$media_id = absint( (string) ( $s['media_id'] ?? '' ) );
			if ( $media_id > 0 ) {
				$url = wp_get_attachment_image_url( $media_id, 'large' );
				if ( $url ) { $step['image'] = $url; }
			}
			$howto_steps[] = $step;
			$pos++;
		}

		$about = implode( ' | ', array_filter( array( $subject, $scale ) ) );
		return array(
			'@context' => 'https://schema.org',
			'@type' => 'HowTo',
			'name' => $name,
			'description' => $this->mb_substr_safe( $desc, 0, 300 ),
			'url' => get_permalink( $post ),
			'about' => $about,
			'supply' => $supply,
			'step' => $howto_steps,
			'dateCreated' => get_the_date( DATE_W3C, $post ),
			'dateModified' => get_the_modified_date( DATE_W3C, $post ),
		);
	}

	private function mb_substr_safe( string $s, int $start, int $len ): string {
		if ( function_exists( 'mb_substr' ) ) { return (string) mb_substr( $s, $start, $len ); }
		return substr( $s, $start, $len );
	}
}
