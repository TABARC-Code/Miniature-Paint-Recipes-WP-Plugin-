<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Schema {
	public function build_howto_schema( \WP_Post $post, string $subject, string $scale, array $paints, array $steps ): array {
		$name = (string) get_the_title( $post );
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_strip_all_tags( (string) $post->post_content );
		$desc = trim( (string) $desc );

		$supply = array();
		foreach ( $paints as $p ) {
			if ( ! is_array( $p ) ) { continue; }
			$brand = trim( (string) ( $p['brand'] ?? '' ) );
			$namep = trim( (string) ( $p['name'] ?? '' ) );
			if ( '' === $brand && '' === $namep ) { continue; }
			$label = trim( implode( ' ', array_filter( array( $brand, $namep ) ) ) );
			$supply[] = array( '@type' => 'HowToSupply', 'name' => $label );
		}

		$howto_steps = array();
		$pos = 1;
		$total_minutes = 0;
		foreach ( $steps as $s ) {
			if ( ! is_array( $s ) ) { continue; }
			$title = trim( (string) ( $s['title'] ?? '' ) );
			$body  = trim( (string) ( $s['body'] ?? '' ) );
			$group = trim( (string) ( $s['group'] ?? '' ) );
			if ( '' === $title && '' === $body && '' === $group ) { continue; }
			$text = trim( implode( ' — ', array_filter( array( $group, $body ) ) ) );
			$total_minutes += $this->minutes_from_text( (string) ( $s['time'] ?? '' ) );
			$step = array(
				'@type' => 'HowToStep',
				'position' => $pos,
				'name' => $title !== '' ? $title : sprintf( 'Step %d', $pos ),
				'text' => $text,
			);
			$media_id = absint( (string) ( $s['media_id'] ?? '' ) );
			if ( $media_id > 0 ) {
				$url = wp_get_attachment_image_url( $media_id, 'large' );
				if ( $url ) { $step['image'] = $url; }
			}
			$howto_steps[] = $step;
			$pos++;
		}

		$about = implode( ' | ', array_filter( array( $subject, $scale ) ) );
		$schema = array(
			'@context' => 'https://schema.org',
			'@type' => 'HowTo',
			'name' => $name,
			'description' => $this->mb_substr_safe( $desc, 0, 300 ),
			'url' => get_permalink( $post ),
			'about' => $about,
			'supply' => $supply,
			'step' => $howto_steps,
			'dateCreated' => get_the_date( DATE_W3C, $post ),
			'dateModified' => get_the_modified_date( DATE_W3C, $post ),
		);

		if ( $total_minutes > 0 ) {
			$hours = intdiv( $total_minutes, 60 );
			$mins  = $total_minutes % 60;
			$schema['totalTime'] = 'PT' . ( $hours ? $hours . 'H' : '' ) . ( $mins ? $mins . 'M' : '' );
		}

		$thumb = get_the_post_thumbnail_url( $post, 'large' );
		if ( $thumb ) { $schema['image'] = $thumb; }

		return $schema;
	}

	/**
	 * Reads times such as "10m", "1h dry" or "1h 30m" and returns whole minutes (0 if none found).
	 */
	public function minutes_from_text( string $text ): int {
		$minutes = 0.0;
		if ( preg_match_all( '/(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b/i', $text, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$value    = (float) $match[1];
				$minutes += ( 'h' === strtolower( $match[2][0] ) ) ? $value * 60 : $value;
			}
		}
		return (int) round( $minutes );
	}

	private function mb_substr_safe( string $s, int $start, int $len ): string {
		if ( function_exists( 'mb_substr' ) ) { return (string) mb_substr( $s, $start, $len ); }
		return substr( $s, $start, $len );
	}
}
