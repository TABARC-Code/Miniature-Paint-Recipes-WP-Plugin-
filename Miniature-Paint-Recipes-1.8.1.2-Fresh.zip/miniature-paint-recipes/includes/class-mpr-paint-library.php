<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Paint_Library {
    public const CPT = 'mpr_paint';

    private const META_CODE = '_mpr_paint_code';
    private const META_HEX  = '_mpr_paint_hex';

    public function register(): void {
        add_action( 'init', array( $this, 'register_cpt' ) );
        add_action( 'add_meta_boxes', array( $this, 'meta_boxes' ) );
        add_action( 'save_post', array( $this, 'save' ), 10, 2 );
        add_action( 'init', array( $this, 'register_meta_rest' ) );

        add_filter( 'manage_' . self::CPT . '_posts_columns', array( $this, 'columns' ) );
        add_action( 'manage_' . self::CPT . '_posts_custom_column', array( $this, 'column_content' ), 10, 2 );

        add_action( 'rest_api_init', array( $this, 'register_rest' ) );

        add_action( 'show_user_profile', array( $this, 'user_profile_field' ) );
        add_action( 'edit_user_profile', array( $this, 'user_profile_field' ) );
        add_action( 'personal_options_update', array( $this, 'save_user_profile_field' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_user_profile_field' ) );
    }

    public function register_cpt(): void {
        $labels = array(
            'name' => __( 'Paints', 'miniature-paint-recipes' ),
            'singular_name' => __( 'Paint', 'miniature-paint-recipes' ),
            'add_new_item' => __( 'Add New Paint', 'miniature-paint-recipes' ),
            'edit_item' => __( 'Edit Paint', 'miniature-paint-recipes' ),
            'menu_name' => __( 'Paint Library', 'miniature-paint-recipes' ),
        );

        register_post_type(
            self::CPT,
            array(
                'labels' => $labels,
                'public' => false,
                'show_ui' => true,
                'show_in_menu' => 'edit.php?post_type=' . MPR_CPT::CPT,
                'show_in_rest' => true,
                'supports' => array( 'title' ),
                'menu_icon' => 'dashicons-art',
            )
        );
    }

    public function meta_boxes(): void {
        add_meta_box(
            'mpr_paint_details',
            __( 'Paint Details', 'miniature-paint-recipes' ),
            array( $this, 'render_box' ),
            self::CPT,
            'normal',
            'high'
        );
    }

    public function render_box( \WP_Post $post ): void {
        wp_nonce_field( 'mpr_save_paint', 'mpr_paint_nonce' );

        $code = (string) get_post_meta( $post->ID, self::META_CODE, true );
        $hex  = (string) get_post_meta( $post->ID, self::META_HEX, true );

        $brand_terms = wp_get_post_terms( $post->ID, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) );
        $range_terms = wp_get_post_terms( $post->ID, MPR_Taxonomies::TAX_RANGE, array( 'fields' => 'names' ) );
        ?>
        <div class="mpr-box">
            <p class="mpr-row">
                <label><strong><?php esc_html_e( 'Brand', 'miniature-paint-recipes' ); ?></strong></label>
                <input type="text" class="widefat" name="mpr_paint_brand" value="<?php echo esc_attr( implode( ', ', (array) $brand_terms ) ); ?>" placeholder="e.g. Citadel, Vallejo, AK" />
                <span class="description"><?php esc_html_e( 'Comma separated. Stored as terms.', 'miniature-paint-recipes' ); ?></span>
            </p>
            <p class="mpr-row">
                <label><strong><?php esc_html_e( 'Range', 'miniature-paint-recipes' ); ?></strong></label>
                <input type="text" class="widefat" name="mpr_paint_range" value="<?php echo esc_attr( implode( ', ', (array) $range_terms ) ); ?>" placeholder="e.g. Contrast, Model Color, Model Air" />
            </p>

            <div class="mpr-grid">
                <input type="text" class="mpr-field" name="mpr_paint_code" value="<?php echo esc_attr( $code ); ?>" placeholder="<?php esc_attr_e( 'Code (optional)', 'miniature-paint-recipes' ); ?>" />
                <input type="text" class="mpr-field mpr-hex" name="mpr_paint_hex" value="<?php echo esc_attr( $hex ); ?>" placeholder="<?php esc_attr_e( '#rrggbb (optional)', 'miniature-paint-recipes' ); ?>" />
            </div>

            <p class="description"><?php esc_html_e( 'Hex is a UI swatch hint, not colour science.', 'miniature-paint-recipes' ); ?></p>
        </div>
        <?php
    }

    public function save( int $post_id, \WP_Post $post ): void {
        if ( self::CPT !== $post->post_type ) { return; }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( ! isset( $_POST['mpr_paint_nonce'] ) || ! wp_verify_nonce( (string) $_POST['mpr_paint_nonce'], 'mpr_save_paint' ) ) { return; }
        if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

        $code = isset( $_POST['mpr_paint_code'] ) ? sanitize_text_field( (string) $_POST['mpr_paint_code'] ) : '';
        $hex  = isset( $_POST['mpr_paint_hex'] ) ? sanitize_text_field( (string) $_POST['mpr_paint_hex'] ) : '';
        $hex = preg_match( '/^#[0-9a-fA-F]{6}$/', $hex ) ? strtolower( $hex ) : '';

        update_post_meta( $post_id, self::META_CODE, $code );
        update_post_meta( $post_id, self::META_HEX, $hex );

        $brand = isset( $_POST['mpr_paint_brand'] ) ? (string) $_POST['mpr_paint_brand'] : '';
        $range = isset( $_POST['mpr_paint_range'] ) ? (string) $_POST['mpr_paint_range'] : '';

        $this->set_terms_from_csv( $post_id, MPR_Taxonomies::TAX_BRAND, $brand );
        $this->set_terms_from_csv( $post_id, MPR_Taxonomies::TAX_RANGE, $range );
    }

    private function set_terms_from_csv( int $post_id, string $tax, string $csv ): void {
        $parts = array_filter( array_map( 'trim', explode( ',', (string) $csv ) ) );
        $parts = array_map( 'sanitize_text_field', $parts );
        wp_set_object_terms( $post_id, $parts, $tax, false );
    }

    public function register_meta_rest(): void {
        $auth = static fn() => current_user_can( 'edit_posts' );

        register_post_meta( self::CPT, self::META_CODE, array(
            'single' => true, 'type' => 'string', 'show_in_rest' => true, 'auth_callback' => $auth,
        ) );
        register_post_meta( self::CPT, self::META_HEX, array(
            'single' => true, 'type' => 'string', 'show_in_rest' => true, 'auth_callback' => $auth,
        ) );
    }

    public function columns( array $cols ): array {
        $cols['mpr_brand'] = __( 'Brand', 'miniature-paint-recipes' );
        $cols['mpr_hex']   = __( 'Swatch', 'miniature-paint-recipes' );
        $cols['mpr_code']  = __( 'Code', 'miniature-paint-recipes' );
        return $cols;
    }

    public function column_content( string $col, int $post_id ): void {
        if ( 'mpr_brand' === $col ) {
            $terms = wp_get_post_terms( $post_id, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) );
            echo esc_html( implode( ', ', (array) $terms ) );
            return;
        }
        if ( 'mpr_hex' === $col ) {
            $hex = (string) get_post_meta( $post_id, self::META_HEX, true );
            if ( $hex && preg_match( '/^#[0-9a-f]{6}$/', $hex ) ) {
                echo '<span style="display:inline-block;width:18px;height:18px;border:1px solid #ccc;border-radius:3px;background:' . esc_attr( $hex ) . '"></span>';
            } else {
                echo '&ndash;';
            }
            return;
        }
        if ( 'mpr_code' === $col ) {
            echo esc_html( (string) get_post_meta( $post_id, self::META_CODE, true ) );
        }
    }

    public function register_rest(): void {
        register_rest_route( 'mpr/v1', '/paints', array(
            'methods' => 'GET',
            'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
            'callback' => array( $this, 'rest_search_paints' ),
            'args' => array(
                'q' => array( 'type' => 'string', 'required' => false ),
                'per_page' => array( 'type' => 'integer', 'required' => false ),
            ),
        ) );
    }

    public function rest_search_paints( \WP_REST_Request $req ): \WP_REST_Response {
        $q = sanitize_text_field( (string) $req->get_param( 'q' ) );
        $per = (int) $req->get_param( 'per_page' );
        if ( $per <= 0 || $per > 50 ) { $per = 20; }

        $args = array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'posts_per_page' => $per,
            's' => $q,
        );

        $posts = get_posts( $args );
        $out = array();
        foreach ( $posts as $p ) {
            $out[] = array(
                'id' => (int) $p->ID,
                'title' => get_the_title( $p ),
                'brand' => implode( ', ', (array) wp_get_post_terms( $p->ID, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) ) ),
                'range' => implode( ', ', (array) wp_get_post_terms( $p->ID, MPR_Taxonomies::TAX_RANGE, array( 'fields' => 'names' ) ) ),
                'hex' => (string) get_post_meta( $p->ID, self::META_HEX, true ),
                'code' => (string) get_post_meta( $p->ID, self::META_CODE, true ),
            );
        }

        return new \WP_REST_Response( $out, 200 );
    }

    public static function get_preferred_brand_term_id( int $user_id ): int {
        $val = (int) get_user_meta( $user_id, '_mpr_preferred_brand_term', true );
        return $val > 0 ? $val : 0;
    }

    public function user_profile_field( \WP_User $user ): void {
        if ( ! current_user_can( 'edit_user', $user->ID ) ) {
            return;
        }

        $term_id = self::get_preferred_brand_term_id( (int) $user->ID );
        $terms = get_terms( array(
            'taxonomy' => MPR_Taxonomies::TAX_BRAND,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
            'number' => 500,
        ) );

        ?>
        <h2><?php esc_html_e( 'Miniature Paint Recipes', 'miniature-paint-recipes' ); ?></h2>
        <table class="form-table" role="presentation">
            <tr>
                <th><label for="mpr_preferred_brand_term"><?php esc_html_e( 'Preferred paint brand', 'miniature-paint-recipes' ); ?></label></th>
                <td>
                    <select name="mpr_preferred_brand_term" id="mpr_preferred_brand_term">
                        <option value="0"><?php esc_html_e( 'No preference', 'miniature-paint-recipes' ); ?></option>
                        <?php foreach ( $terms as $t ) : ?>
                            <option value="<?php echo esc_attr( (string) $t->term_id ); ?>" <?php selected( (int) $t->term_id, $term_id ); ?>>
                                <?php echo esc_html( $t->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Used by equivalents mapping when a recipe paint is linked to the global library.', 'miniature-paint-recipes' ); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    public function save_user_profile_field( int $user_id ): void {
        if ( ! current_user_can( 'edit_user', $user_id ) ) { return; }
        $term_id = isset( $_POST['mpr_preferred_brand_term'] ) ? absint( $_POST['mpr_preferred_brand_term'] ) : 0;
        update_user_meta( $user_id, '_mpr_preferred_brand_term', $term_id > 0 ? $term_id : 0 );
    }
}
