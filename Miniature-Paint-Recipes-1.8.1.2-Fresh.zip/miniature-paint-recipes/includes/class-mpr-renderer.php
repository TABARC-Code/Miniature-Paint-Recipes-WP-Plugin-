<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Renderer {
	private const CACHE_GROUP = 'mpr';

	public function register(): void {
		add_shortcode( 'paint_recipe', array( $this, 'shortcode' ) );
		add_shortcode( 'paint_recipe_submit', array( $this, 'submission_shortcode' ) );
		add_filter( 'the_content', array( $this, 'maybe_append_to_cpt' ) );
	}

	public function shortcode( array $atts ): string {
		$atts = shortcode_atts( array( 'id' => 0, 'print' => 0 ), $atts, 'paint_recipe' );
		$id = (int) $atts['id'];
		if ( $id <= 0 ) { return ''; }
		return $this->render_card( $id, (int) $atts['print'] === 1 );
	}

	public function maybe_append_to_cpt( string $content ): string {
		if ( ! is_singular( MPR_CPT::CPT ) ) { return $content; }
		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) { return $content; }
		if ( has_shortcode( $content, 'paint_recipe' ) ) { return $content; }
		return $content . $this->render_card( $post_id, false );
	}

	public function render_card( int $post_id, bool $print ): string {
		$post = get_post( $post_id );
		if ( ! $post || MPR_CPT::CPT !== $post->post_type ) { return ''; }
		if ( 'publish' !== $post->post_status && ! current_user_can( 'read_post', $post_id ) ) { return ''; }
		$key = ( $print ? 'print:' : 'card:' ) . $post_id . ':' . MPR_Plugin::cache_salt();
		$hit = wp_cache_get( $key, self::CACHE_GROUP );
		if ( is_string( $hit ) && $hit !== '' ) { return $hit; }
		$subject = (string) get_post_meta( $post_id, MPR_Meta::META_SUBJECT, true );
		$scale   = (string) get_post_meta( $post_id, MPR_Meta::META_SCALE, true );
		$paints  = get_post_meta( $post_id, MPR_Meta::META_PAINTS, true );
		$steps   = get_post_meta( $post_id, MPR_Meta::META_STEPS, true );
		if ( ! is_array( $paints ) ) { $paints = array(); }
		if ( ! is_array( $steps ) )  { $steps = array(); }

		$template = $this->resolve_template( $print ? 'print.php' : 'card.php' );
		ob_start();
		$schema = ( new MPR_Schema() )->build_howto_schema( $post, $subject, $scale, $paints, $steps );
		if ( $template && file_exists( $template ) ) {
			include $template;
		} else {
			echo $this->fallback_render( $post, $subject, $scale, $paints, $steps, $schema, $print ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$html = (string) ob_get_clean();
		if ( $html !== '' ) { wp_cache_set( $key, $html, self::CACHE_GROUP, 5 * MINUTE_IN_SECONDS ); }
		return $html;
	}

	private function resolve_template( string $name ): string {
		$theme_path = trailingslashit( get_stylesheet_directory() ) . 'mpr/' . $name;
		$plugin_path = MPR_DIR . 'templates/' . $name;
		$path = file_exists( $theme_path ) ? $theme_path : $plugin_path;
		return (string) apply_filters( 'mpr_template_path', $path, $name );
	}

	public function submission_shortcode(): string {
		$message = '';
		$error = '';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['mpr_submit_recipe_nonce'] ) ) {
			if ( ! wp_verify_nonce( (string) $_POST['mpr_submit_recipe_nonce'], 'mpr_submit_recipe' ) ) {
				$error = __( 'Submission failed nonce check.', 'miniature-paint-recipes' );
			} else {
				$result = $this->handle_submission();
				if ( is_wp_error( $result ) ) {
					$error = $result->get_error_message();
				} else {
					$message = __( 'Submission received. It is now waiting for moderation instead of being sprayed directly onto the live site.', 'miniature-paint-recipes' );
				}
			}
		}

		ob_start();
		?>
		<div class="mpr-submission-form">
			<?php if ( $message ) : ?><div class="notice notice-success"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
			<?php if ( $error ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div><?php endif; ?>
			<form method="post">
				<?php wp_nonce_field( 'mpr_submit_recipe', 'mpr_submit_recipe_nonce' ); ?>
				<p><label><strong><?php esc_html_e( 'Recipe title', 'miniature-paint-recipes' ); ?></strong></label><br><input class="widefat" type="text" name="mpr_submit_title" required></p>
				<p><label><strong><?php esc_html_e( 'Subject', 'miniature-paint-recipes' ); ?></strong></label><br><input class="widefat" type="text" name="mpr_submit_subject"></p>
				<p><label><strong><?php esc_html_e( 'Scale', 'miniature-paint-recipes' ); ?></strong></label><br><input class="widefat" type="text" name="mpr_submit_scale"></p>
				<p><label><strong><?php esc_html_e( 'Paints', 'miniature-paint-recipes' ); ?></strong></label><br><textarea class="widefat" rows="6" name="mpr_submit_paints" placeholder="One per line. Example: Base | Citadel | Base | Abaddon Black"></textarea></p>
				<p><label><strong><?php esc_html_e( 'Steps', 'miniature-paint-recipes' ); ?></strong></label><br><textarea class="widefat" rows="8" name="mpr_submit_steps" placeholder="One per line. Example: Prep | Prime black and let it cure."></textarea></p>
				<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Submit recipe', 'miniature-paint-recipes' ); ?></button></p>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private function handle_submission() {
		$title = isset( $_POST['mpr_submit_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['mpr_submit_title'] ) ) : '';
		if ( '' === $title ) { return new \WP_Error( 'mpr_submit_title', __( 'Title is required.', 'miniature-paint-recipes' ) ); }
		$post_id = wp_insert_post( array(
			'post_type' => MPR_CPT::CPT,
			'post_status' => 'pending',
			'post_title' => $title,
		), true );
		if ( is_wp_error( $post_id ) ) { return $post_id; }
		$subject = isset( $_POST['mpr_submit_subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['mpr_submit_subject'] ) ) : '';
		$scale = isset( $_POST['mpr_submit_scale'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['mpr_submit_scale'] ) ) : '';
		$paints_text = isset( $_POST['mpr_submit_paints'] ) ? (string) wp_unslash( $_POST['mpr_submit_paints'] ) : '';
		$steps_text = isset( $_POST['mpr_submit_steps'] ) ? (string) wp_unslash( $_POST['mpr_submit_steps'] ) : '';
		$paints = $this->parse_submission_paints( $paints_text );
		$steps = $this->parse_submission_steps( $steps_text, $paints );
		$meta = new MPR_Meta();
		update_post_meta( $post_id, MPR_Meta::META_SUBJECT, $subject );
		update_post_meta( $post_id, MPR_Meta::META_SCALE, $scale );
		update_post_meta( $post_id, MPR_Meta::META_BATCH_SIZE, 1 );
		update_post_meta( $post_id, MPR_Meta::META_PROFILE, 'infantry' );
		update_post_meta( $post_id, MPR_Meta::META_PAINTS, $meta->sanitize_repeater_array( $paints, 'paint' ) );
		$allowed = array_map( static function( $p ) { return (string) ( $p['id'] ?? '' ); }, $paints );
		update_post_meta( $post_id, MPR_Meta::META_STEPS, $meta->sanitize_repeater_array( $steps, 'step', $allowed ) );
		return $post_id;
	}

	private function parse_submission_paints( string $text ): array {
		$rows = preg_split( '/\r\n|\r|\n/', trim( $text ) );
		$out = array();
		foreach ( $rows as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) { continue; }
			$parts = array_map( 'trim', explode( '|', $line ) );
			$out[] = array(
				'id' => wp_generate_uuid4(),
				'role' => $parts[0] ?? '',
				'brand' => $parts[1] ?? '',
				'range' => $parts[2] ?? '',
				'name' => $parts[3] ?? ( $parts[0] ?? '' ),
				'calc_amount' => '',
				'calc_unit' => 'drops',
			);
		}
		return $out;
	}

	private function parse_submission_steps( string $text, array $paints ): array {
		$rows = preg_split( '/\r\n|\r|\n/', trim( $text ) );
		$paint_ids = array();
		foreach ( $paints as $paint ) {
			if ( ! empty( $paint['id'] ) ) { $paint_ids[] = (string) $paint['id']; }
		}
		$out = array();
		foreach ( $rows as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) { continue; }
			$parts = array_map( 'trim', explode( '|', $line, 2 ) );
			$out[] = array(
				'group' => $parts[0] ?? '',
				'title' => $parts[0] ?? '',
				'body' => $parts[1] ?? $line,
				'paints_used_json' => wp_json_encode( array_slice( $paint_ids, 0, min( 2, count( $paint_ids ) ) ) ),
			);
		}
		return $out;
	}

	private function fallback_render( \WP_Post $post, string $subject, string $scale, array $paints, array $steps, array $schema, bool $print ): string {
		$title = esc_html( get_the_title( $post ) );
		$meta  = esc_html( trim( $subject . ( $subject && $scale ? ' | ' : '' ) . $scale ) );
		$out  = $print ? '<!doctype html><html><head><meta charset="utf-8"><title>' . $title . '</title></head><body>' : '';
		$out .= '<div class="mpr-card mpr-card--fallback"><h2>' . $title . '</h2>';
		if ( $meta ) { $out .= '<p>' . $meta . '</p>'; }
		if ( ! empty( $paints ) ) {
			$out .= '<h3>Paint stack</h3><ul>';
			foreach ( $paints as $p ) {
				if ( ! is_array( $p ) ) { continue; }
				$label = trim( (string) ( $p['role'] ?? '' ) . ' — ' . ( $p['brand'] ?? '' ) . ' ' . ( $p['name'] ?? '' ) );
				if ( $label !== '' ) { $out .= '<li>' . esc_html( $label ) . '</li>'; }
			}
			$out .= '</ul>';
		}
		if ( ! empty( $steps ) ) {
			$out .= '<h3>Steps</h3><ol>';
			foreach ( $steps as $s ) {
				if ( ! is_array( $s ) ) { continue; }
				$st = trim( (string) ( $s['title'] ?? '' ) );
				$bd = trim( (string) ( $s['body'] ?? '' ) );
				if ( $st === '' && $bd === '' ) { continue; }
				$out .= '<li><strong>' . esc_html( $st ?: 'Step' ) . '</strong><br>' . nl2br( esc_html( $bd ) ) . '</li>';
			}
			$out .= '</ol>';
		}
		$out .= '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script></div>';
		$out .= $print ? '</body></html>' : '';
		return $out;
	}
}
