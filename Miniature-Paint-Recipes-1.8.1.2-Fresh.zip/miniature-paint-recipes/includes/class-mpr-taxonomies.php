<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Taxonomies {
	public const TAX_BRAND     = 'mpr_brand';
	public const TAX_RANGE     = 'mpr_range';
	public const TAX_STYLE     = 'mpr_style';
	public const TAX_TECHNIQUE = 'mpr_technique';
	public const TAX_FACTION   = 'mpr_faction';

	public function register(): void {
		$this->register_tax( self::TAX_BRAND, __( 'Brand', 'miniature-paint-recipes' ), __( 'Brands', 'miniature-paint-recipes' ) );
		$this->register_tax( self::TAX_RANGE, __( 'Range', 'miniature-paint-recipes' ), __( 'Ranges', 'miniature-paint-recipes' ) );
		$this->register_tax( self::TAX_STYLE, __( 'Style', 'miniature-paint-recipes' ), __( 'Styles', 'miniature-paint-recipes' ) );
		$this->register_tax( self::TAX_TECHNIQUE, __( 'Technique', 'miniature-paint-recipes' ), __( 'Techniques', 'miniature-paint-recipes' ) );
		$this->register_tax( self::TAX_FACTION, __( 'Faction', 'miniature-paint-recipes' ), __( 'Factions', 'miniature-paint-recipes' ) );
	}

	private function register_tax( string $taxonomy, string $singular, string $plural ): void {
		$labels = array(
			'name'          => $plural,
			'singular_name' => $singular,
			'search_items'  => sprintf( __( 'Search %s', 'miniature-paint-recipes' ), $plural ),
			'all_items'     => sprintf( __( 'All %s', 'miniature-paint-recipes' ), $plural ),
			'edit_item'     => sprintf( __( 'Edit %s', 'miniature-paint-recipes' ), $singular ),
			'update_item'   => sprintf( __( 'Update %s', 'miniature-paint-recipes' ), $singular ),
			'add_new_item'  => sprintf( __( 'Add New %s', 'miniature-paint-recipes' ), $singular ),
			'new_item_name' => sprintf( __( 'New %s Name', 'miniature-paint-recipes' ), $singular ),
			'menu_name'     => $plural,
		);

		register_taxonomy(
			$taxonomy,
			array( MPR_CPT::CPT, MPR_Paint_Library::CPT ),
			array(
				'hierarchical'      => false,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array( 'slug' => $taxonomy ),
			)
		);
	}
}
