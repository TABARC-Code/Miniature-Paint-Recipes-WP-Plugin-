<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_CPT {
	public const CPT = 'mpr_paint_recipe';

	public function register(): void {
		$labels = array(
			'name'          => __( 'Paint Recipes', 'miniature-paint-recipes' ),
			'singular_name' => __( 'Paint Recipe', 'miniature-paint-recipes' ),
			'add_new_item'  => __( 'Add New Paint Recipe', 'miniature-paint-recipes' ),
			'edit_item'     => __( 'Edit Paint Recipe', 'miniature-paint-recipes' ),
			'view_item'     => __( 'View Paint Recipe', 'miniature-paint-recipes' ),
			'search_items'  => __( 'Search Paint Recipes', 'miniature-paint-recipes' ),
			'not_found'     => __( 'No paint recipes found', 'miniature-paint-recipes' ),
			'menu_name'     => __( 'Paint Recipes', 'miniature-paint-recipes' ),
		);

		register_post_type(
			self::CPT,
			array(
				'labels'       => $labels,
				'public'       => true,
				'show_in_rest' => true,
				'has_archive'  => true,
				'menu_icon'    => 'dashicons-art',
				'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
				'rewrite'      => array( 'slug' => 'paint-recipes' ),
			)
		);
	}
}
