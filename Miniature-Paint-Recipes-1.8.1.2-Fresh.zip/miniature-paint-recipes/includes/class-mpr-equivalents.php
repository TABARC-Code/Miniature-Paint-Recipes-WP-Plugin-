<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Equivalents {
    private const TABLE = 'mpr_paint_equivalents';

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    public function maybe_create_table(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $wpdb->prefix . self::TABLE;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            from_paint_id BIGINT(20) UNSIGNED NOT NULL,
            to_paint_id BIGINT(20) UNSIGNED NOT NULL,
            score FLOAT NOT NULL DEFAULT 0.5,
            notes TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY from_paint_id (from_paint_id),
            KEY to_paint_id (to_paint_id)
        ) {$charset};";

        dbDelta( $sql );
    }

    public function admin_menu(): void {
        add_submenu_page(
            'edit.php?post_type=' . MPR_Paint_Library::CPT,
            __( 'Equivalents', 'miniature-paint-recipes' ),
            __( 'Equivalents', 'miniature-paint-recipes' ),
            'manage_options',
            'mpr-equivalents',
            array( $this, 'render_page' )
        );
    }

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $msg = '';
        $err = '';

        if ( isset( $_POST['mpr_equiv_action'] ) && check_admin_referer( 'mpr_equiv', 'mpr_equiv_nonce' ) ) {
            $action = sanitize_key( (string) $_POST['mpr_equiv_action'] );

            if ( 'add' === $action ) {
                $from = absint( $_POST['from_paint_id'] ?? 0 );
                $to   = absint( $_POST['to_paint_id'] ?? 0 );
                $score = isset( $_POST['score'] ) ? (float) $_POST['score'] : 0.5;
                $score = max( 0.0, min( 1.0, $score ) );
                $notes = isset( $_POST['notes'] ) ? sanitize_textarea_field( (string) $_POST['notes'] ) : '';

                if ( $from <= 0 || $to <= 0 || $from === $to ) {
                    $err = __( 'Pick two different paints.', 'miniature-paint-recipes' );
                } else {
                    $this->insert_equiv( $from, $to, $score, $notes );
                    $msg = __( 'Equivalent saved.', 'miniature-paint-recipes' );
                }
            } elseif ( 'delete' === $action ) {
                $id = absint( $_POST['equiv_id'] ?? 0 );
                if ( $id > 0 ) {
                    $this->delete_equiv( $id );
                    $msg = __( 'Equivalent deleted.', 'miniature-paint-recipes' );
                }
            }
        }

        $rows = $this->list_equivs();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Paint Equivalents', 'miniature-paint-recipes' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Manual mapping. “Close enough” is a human judgement call, not a database fact.', 'miniature-paint-recipes' ); ?></p>

            <?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
            <?php if ( $err ) : ?><div class="notice notice-error"><p><?php echo esc_html( $err ); ?></p></div><?php endif; ?>

            <form method="post" style="max-width: 900px;">
                <?php wp_nonce_field( 'mpr_equiv', 'mpr_equiv_nonce' ); ?>
                <input type="hidden" name="mpr_equiv_action" value="add" />
                <table class="form-table" role="presentation">
                    <tr>
                        <th><label for="from_paint_id"><?php esc_html_e( 'From paint', 'miniature-paint-recipes' ); ?></label></th>
                        <td><?php $this->paint_select( 'from_paint_id', 0 ); ?></td>
                    </tr>
                    <tr>
                        <th><label for="to_paint_id"><?php esc_html_e( 'To paint', 'miniature-paint-recipes' ); ?></label></th>
                        <td><?php $this->paint_select( 'to_paint_id', 0 ); ?></td>
                    </tr>
                    <tr>
                        <th><label for="score"><?php esc_html_e( 'Confidence (0–1)', 'miniature-paint-recipes' ); ?></label></th>
                        <td><input name="score" id="score" type="number" min="0" max="1" step="0.05" value="0.75" /></td>
                    </tr>
                    <tr>
                        <th><label for="notes"><?php esc_html_e( 'Notes', 'miniature-paint-recipes' ); ?></label></th>
                        <td><textarea name="notes" id="notes" rows="3" class="large-text"></textarea></td>
                    </tr>
                </table>
                <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Add mapping', 'miniature-paint-recipes' ); ?></button></p>
            </form>

            <h2><?php esc_html_e( 'Existing mappings', 'miniature-paint-recipes' ); ?></h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'From', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'To', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Score', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Notes', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Action', 'miniature-paint-recipes' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="5"><?php esc_html_e( 'No mappings yet.', 'miniature-paint-recipes' ); ?></td></tr>
                <?php else : ?>
                    <?php foreach ( $rows as $r ) : ?>
                        <tr>
                            <td><?php echo esc_html( get_the_title( (int) $r['from_paint_id'] ) ); ?></td>
                            <td><?php echo esc_html( get_the_title( (int) $r['to_paint_id'] ) ); ?></td>
                            <td><?php echo esc_html( (string) $r['score'] ); ?></td>
                            <td><?php echo esc_html( (string) $r['notes'] ); ?></td>
                            <td>
                                <form method="post">
                                    <?php wp_nonce_field( 'mpr_equiv', 'mpr_equiv_nonce' ); ?>
                                    <input type="hidden" name="mpr_equiv_action" value="delete" />
                                    <input type="hidden" name="equiv_id" value="<?php echo esc_attr( (string) $r['id'] ); ?>" />
                                    <button type="submit" class="button"><?php esc_html_e( 'Delete', 'miniature-paint-recipes' ); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private function paint_select( string $name, int $selected ): void {
        $paints = get_posts( array(
            'post_type' => MPR_Paint_Library::CPT,
            'post_status' => 'publish',
            'posts_per_page' => 500,
            'orderby' => 'title',
            'order' => 'ASC',
        ) );
        echo '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $name ) . '">';
        echo '<option value="0">' . esc_html__( 'Select…', 'miniature-paint-recipes' ) . '</option>';
        foreach ( $paints as $p ) {
            echo '<option value="' . esc_attr( (string) $p->ID ) . '" ' . selected( (int) $p->ID, $selected, false ) . '>' . esc_html( get_the_title( $p ) ) . '</option>';
        }
        echo '</select>';
    }

    private function insert_equiv( int $from, int $to, float $score, string $notes ): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        $wpdb->insert(
            $table,
            array(
                'from_paint_id' => $from,
                'to_paint_id' => $to,
                'score' => $score,
                'notes' => $notes,
            ),
            array( '%d', '%d', '%f', '%s' )
        );
    }

    private function delete_equiv( int $id ): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
    }

    private function list_equivs(): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $rows = $wpdb->get_results( "SELECT id, from_paint_id, to_paint_id, score, notes FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A );
        return is_array( $rows ) ? $rows : array();
    }

    public function resolve_preferred_equivalent( int $from_paint_id, int $preferred_brand_term_id ): int {
        if ( $from_paint_id <= 0 || $preferred_brand_term_id <= 0 ) { return 0; }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        $sql = $wpdb->prepare(
            "SELECT e.to_paint_id, e.score
             FROM {$table} e
             INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = e.to_paint_id
             INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             WHERE e.from_paint_id = %d AND tt.taxonomy = %s AND tt.term_id = %d
             ORDER BY e.score DESC, e.id DESC
             LIMIT 1",
            $from_paint_id,
            MPR_Taxonomies::TAX_BRAND,
            $preferred_brand_term_id
        );

        $row = $wpdb->get_row( $sql, ARRAY_A );
        if ( ! is_array( $row ) || empty( $row['to_paint_id'] ) ) {
            return 0;
        }

        return (int) $row['to_paint_id'];
    }
}
