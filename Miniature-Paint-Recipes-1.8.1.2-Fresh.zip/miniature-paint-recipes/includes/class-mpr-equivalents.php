<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Equivalents {
    private const TABLE = 'mpr_paint_equivalents';

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    public function maybe_create_table(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $wpdb->prefix . self::TABLE;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            from_paint_id BIGINT(20) UNSIGNED NOT NULL,
            to_paint_id BIGINT(20) UNSIGNED NOT NULL,
            score FLOAT NOT NULL DEFAULT 0.5,
            notes TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY from_paint_id (from_paint_id),
            KEY to_paint_id (to_paint_id)
        ) {$charset};";

        dbDelta( $sql );
    }

    public function admin_menu(): void {
        add_submenu_page(
            'edit.php?post_type=' . MPR_Paint_Library::CPT,
            __( 'Equivalents', 'miniature-paint-recipes' ),
            __( 'Equivalents', 'miniature-paint-recipes' ),
            'manage_options',
            'mpr-equivalents',
            array( $this, 'render_page' )
        );
    }

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $msg = '';
        $err = '';

        if ( isset( $_POST['mpr_equiv_action'] ) && check_admin_referer( 'mpr_equiv', 'mpr_equiv_nonce' ) ) {
            $action = sanitize_key( wp_unslash( (string) $_POST['mpr_equiv_action'] ) );

            if ( 'add' === $action ) {
                $from = absint( wp_unslash( $_POST['from_paint_id'] ?? 0 ) );
                $to   = absint( wp_unslash( $_POST['to_paint_id'] ?? 0 ) );
                $score = isset( $_POST['score'] ) ? (float) wp_unslash( $_POST['score'] ) : 0.5;
                $score = max( 0.0, min( 1.0, $score ) );
                $notes = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['notes'] ) ) : '';

                if ( $from <= 0 || $to <= 0 || $from === $to ) {
                    $err = __( 'Pick two different paints.', 'miniature-paint-recipes' );
                } elseif ( $this->pair_exists( $from, $to ) ) {
                    $err = __( 'Those two paints are already mapped (mappings work both ways).', 'miniature-paint-recipes' );
                } else {
                    if ( $this->insert_equiv( $from, $to, $score, $notes ) ) {
                        $msg = __( 'Equivalent saved.', 'miniature-paint-recipes' );
                    } else {
                        $err = __( 'Could not save the equivalent.', 'miniature-paint-recipes' );
                    }
                }
            } elseif ( 'delete' === $action ) {
                $id = absint( wp_unslash( $_POST['equiv_id'] ?? 0 ) );
                if ( $id > 0 ) {
                    $this->delete_equiv( $id );
                    $msg = __( 'Equivalent deleted.', 'miniature-paint-recipes' );
                }
            }
        }

        $suggest_id  = isset( $_GET['suggest_for'] ) ? absint( wp_unslash( $_GET['suggest_for'] ) ) : 0;
        $suggestions = $suggest_id > 0 ? $this->suggest_by_colour( $suggest_id ) : array();
        $rows        = $this->list_equivs();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Paint Equivalents', 'miniature-paint-recipes' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Manual mapping. Mappings work both ways.', 'miniature-paint-recipes' ); ?></p>

            <?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
            <?php if ( $err ) : ?><div class="notice notice-error"><p><?php echo esc_html( $err ); ?></p></div><?php endif; ?>

            <form method="post" style="max-width: 900px;">
                <?php wp_nonce_field( 'mpr_equiv', 'mpr_equiv_nonce' ); ?>
                <input type="hidden" name="mpr_equiv_action" value="add" />
                <table class="form-table" role="presentation">
                    <tr>
                        <th><label for="from_paint_id"><?php esc_html_e( 'From paint', 'miniature-paint-recipes' ); ?></label></th>
                        <td><?php $this->paint_select( 'from_paint_id', 0 ); ?></td>
                    </tr>
                    <tr>
                        <th><label for="to_paint_id"><?php esc_html_e( 'To paint', 'miniature-paint-recipes' ); ?></label></th>
                        <td><?php $this->paint_select( 'to_paint_id', 0 ); ?></td>
                    </tr>
                    <tr>
                        <th><label for="score"><?php esc_html_e( 'Confidence (0–1)', 'miniature-paint-recipes' ); ?></label></th>
                        <td><input name="score" id="score" type="number" min="0" max="1" step="0.05" value="0.75" /></td>
                    </tr>
                    <tr>
                        <th><label for="notes"><?php esc_html_e( 'Notes', 'miniature-paint-recipes' ); ?></label></th>
                        <td><textarea name="notes" id="notes" rows="3" class="large-text"></textarea></td>
                    </tr>
                </table>
                <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Add mapping', 'miniature-paint-recipes' ); ?></button></p>
            </form>

            <h2><?php esc_html_e( 'Suggest by colour', 'miniature-paint-recipes' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Pick a paint to see the closest colours from other brands in the library. Matches use the stored hex values and are approximate, so check them against real paint before saving.', 'miniature-paint-recipes' ); ?></p>
            <form method="get">
                <input type="hidden" name="post_type" value="<?php echo esc_attr( MPR_Paint_Library::CPT ); ?>" />
                <input type="hidden" name="page" value="mpr-equivalents" />
                <?php $this->paint_select( 'suggest_for', $suggest_id ); ?>
                <button type="submit" class="button"><?php esc_html_e( 'Find matches', 'miniature-paint-recipes' ); ?></button>
            </form>

            <?php if ( $suggest_id > 0 && null === self::hex_to_lab( (string) get_post_meta( $suggest_id, MPR_Paint_Library::META_HEX, true ) ) ) : ?>
                <p><?php esc_html_e( 'That paint has no hex colour yet, so there is nothing to match against.', 'miniature-paint-recipes' ); ?></p>
            <?php elseif ( $suggest_id > 0 && empty( $suggestions ) ) : ?>
                <p><?php esc_html_e( 'No matches found. Other brands may have no hex colours yet, or every close match is already mapped.', 'miniature-paint-recipes' ); ?></p>
            <?php elseif ( ! empty( $suggestions ) ) : ?>
                <table class="widefat striped" style="max-width: 900px; margin-top: 12px;">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Colour', 'miniature-paint-recipes' ); ?></th>
                            <th><?php esc_html_e( 'Paint', 'miniature-paint-recipes' ); ?></th>
                            <th><?php esc_html_e( 'Brand', 'miniature-paint-recipes' ); ?></th>
                            <th><?php esc_html_e( 'Difference', 'miniature-paint-recipes' ); ?></th>
                            <th><?php esc_html_e( 'Action', 'miniature-paint-recipes' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $suggestions as $s ) : ?>
                        <tr>
                            <td><span style="display:inline-block;width:18px;height:18px;border:1px solid #ccc;border-radius:3px;background:<?php echo esc_attr( $s['hex'] ); ?>"></span></td>
                            <td><?php echo esc_html( $s['title'] ); ?></td>
                            <td><?php echo esc_html( $s['brand'] ); ?></td>
                            <td><?php echo esc_html( (string) $s['delta'] ); ?></td>
                            <td>
                                <form method="post">
                                    <?php wp_nonce_field( 'mpr_equiv', 'mpr_equiv_nonce' ); ?>
                                    <input type="hidden" name="mpr_equiv_action" value="add" />
                                    <input type="hidden" name="from_paint_id" value="<?php echo esc_attr( (string) $suggest_id ); ?>" />
                                    <input type="hidden" name="to_paint_id" value="<?php echo esc_attr( (string) $s['id'] ); ?>" />
                                    <input type="hidden" name="score" value="<?php echo esc_attr( (string) round( max( 0.0, 1 - $s['delta'] / 40 ), 2 ) ); ?>" />
                                    <input type="hidden" name="notes" value="<?php echo esc_attr( sprintf( __( 'Colour match (difference %s)', 'miniature-paint-recipes' ), $s['delta'] ) ); ?>" />
                                    <button type="submit" class="button"><?php esc_html_e( 'Add mapping', 'miniature-paint-recipes' ); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h2><?php esc_html_e( 'Existing mappings', 'miniature-paint-recipes' ); ?></h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'From', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'To', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Score', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Notes', 'miniature-paint-recipes' ); ?></th>
                        <th><?php esc_html_e( 'Action', 'miniature-paint-recipes' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="5"><?php esc_html_e( 'No mappings yet.', 'miniature-paint-recipes' ); ?></td></tr>
                <?php else : ?>
                    <?php foreach ( $rows as $r ) : ?>
                        <tr>
                            <td><?php echo esc_html( get_the_title( (int) $r['from_paint_id'] ) ); ?></td>
                            <td><?php echo esc_html( get_the_title( (int) $r['to_paint_id'] ) ); ?></td>
                            <td><?php echo esc_html( (string) $r['score'] ); ?></td>
                            <td><?php echo esc_html( (string) $r['notes'] ); ?></td>
                            <td>
                                <form method="post">
                                    <?php wp_nonce_field( 'mpr_equiv', 'mpr_equiv_nonce' ); ?>
                                    <input type="hidden" name="mpr_equiv_action" value="delete" />
                                    <input type="hidden" name="equiv_id" value="<?php echo esc_attr( (string) $r['id'] ); ?>" />
                                    <button type="submit" class="button"><?php esc_html_e( 'Delete', 'miniature-paint-recipes' ); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private function paint_select( string $name, int $selected ): void {
        $paints = get_posts( array(
            'post_type' => MPR_Paint_Library::CPT,
            'post_status' => 'publish',
            'posts_per_page' => 500,
            'orderby' => 'title',
            'order' => 'ASC',
        ) );
        echo '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $name ) . '">';
        echo '<option value="0">' . esc_html__( 'Select…', 'miniature-paint-recipes' ) . '</option>';
        foreach ( $paints as $p ) {
            echo '<option value="' . esc_attr( (string) $p->ID ) . '" ' . selected( (int) $p->ID, $selected, false ) . '>' . esc_html( get_the_title( $p ) ) . '</option>';
        }
        echo '</select>';
    }

    private function insert_equiv( int $from, int $to, float $score, string $notes ): bool {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        $result = $wpdb->insert(
            $table,
            array(
                'from_paint_id' => $from,
                'to_paint_id' => $to,
                'score' => $score,
                'notes' => $notes,
            ),
            array( '%d', '%d', '%f', '%s' )
        );

        return false !== $result;
    }

    private function delete_equiv( int $id ): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
    }

    private function list_equivs(): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $rows = $wpdb->get_results( "SELECT id, from_paint_id, to_paint_id, score, notes FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A );
        return is_array( $rows ) ? $rows : array();
    }

    /** @var array<string,int> Per-request memo so repeated paints cost one lookup. */
    private array $resolved = array();

    /** @var array<int,int[]> Per-request memo of mapped paints. */
    private array $equivalents = array();

    /**
     * Mappings work both ways: if A is close to B, B resolves to A as well.
     * Returns the best-scoring published paint that carries the preferred brand term, or 0.
     */
    public function resolve_preferred_equivalent( int $from_paint_id, int $preferred_brand_term_id ): int {
        if ( $from_paint_id <= 0 || $preferred_brand_term_id <= 0 ) { return 0; }

        $memo_key = $from_paint_id . ':' . $preferred_brand_term_id;
        if ( isset( $this->resolved[ $memo_key ] ) ) { return $this->resolved[ $memo_key ]; }

        $found = 0;
        foreach ( $this->equivalent_ids( $from_paint_id ) as $other ) {
            if ( has_term( $preferred_brand_term_id, MPR_Taxonomies::TAX_BRAND, $other ) ) {
                $found = $other;
                break;
            }
        }

        $this->resolved[ $memo_key ] = $found;
        return $found;
    }

    /**
     * Published paints mapped to this one, in either direction, best score first.
     *
     * @return int[]
     */
    public function equivalent_ids( int $paint_id ): array {
        if ( $paint_id <= 0 ) { return array(); }
        if ( isset( $this->equivalents[ $paint_id ] ) ) { return $this->equivalents[ $paint_id ]; }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT from_paint_id, to_paint_id FROM {$table} WHERE from_paint_id = %d OR to_paint_id = %d ORDER BY score DESC, id DESC LIMIT 50",
                $paint_id,
                $paint_id
            ),
            ARRAY_A
        );

        $ids = array();
        foreach ( is_array( $rows ) ? $rows : array() as $row ) {
            $other = (int) $row['from_paint_id'] === $paint_id ? (int) $row['to_paint_id'] : (int) $row['from_paint_id'];
            if ( $other > 0 && 'publish' === get_post_status( $other ) ) { $ids[] = $other; }
        }

        $this->equivalents[ $paint_id ] = array_values( array_unique( $ids ) );
        return $this->equivalents[ $paint_id ];
    }

    /**
     * sRGB hex (#rrggbb) to CIE Lab under D65. Returns null for anything else.
     *
     * @return float[]|null
     */
    public static function hex_to_lab( string $hex ): ?array {
        if ( ! preg_match( '/^#[0-9a-f]{6}$/i', $hex ) ) { return null; }

        $rgb = array_map(
            static function ( $part ) {
                $c = hexdec( $part ) / 255;
                return $c <= 0.04045 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
            },
            str_split( substr( $hex, 1 ), 2 )
        );

        $x = ( 0.4124564 * $rgb[0] + 0.3575761 * $rgb[1] + 0.1804375 * $rgb[2] ) / 0.95047;
        $y = ( 0.2126729 * $rgb[0] + 0.7151522 * $rgb[1] + 0.0721750 * $rgb[2] );
        $z = ( 0.0193339 * $rgb[0] + 0.1191920 * $rgb[1] + 0.9503041 * $rgb[2] ) / 1.08883;

        $f = static function ( $t ) {
            return $t > 0.008856 ? pow( $t, 1 / 3 ) : ( 7.787 * $t ) + 16 / 116;
        };
        $fx = $f( $x );
        $fy = $f( $y );
        $fz = $f( $z );

        return array( 116 * $fy - 16, 500 * ( $fx - $fy ), 200 * ( $fy - $fz ) );
    }

    /**
     * Colour difference between two Lab colours (CIE76). Around 2 is barely visible; above 10 is clearly different.
     *
     * @param float[] $a
     * @param float[] $b
     */
    public static function delta_e( array $a, array $b ): float {
        return sqrt( ( $a[0] - $b[0] ) ** 2 + ( $a[1] - $b[1] ) ** 2 + ( $a[2] - $b[2] ) ** 2 );
    }

    /**
     * Closest-coloured library paints from other brands that are not already mapped to this one.
     *
     * @return array<int,array{id:int,title:string,brand:string,hex:string,delta:float}>
     */
    public function suggest_by_colour( int $paint_id, int $limit = 10 ): array {
        $source = self::hex_to_lab( (string) get_post_meta( $paint_id, MPR_Paint_Library::META_HEX, true ) );
        if ( null === $source ) { return array(); }

        $source_brands = wp_get_post_terms( $paint_id, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'ids' ) );
        $source_brands = is_array( $source_brands ) ? $source_brands : array();
        $mapped        = $this->equivalent_ids( $paint_id );

        $query = new \WP_Query( array(
            'post_type'      => MPR_Paint_Library::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => 3000,
            'no_found_rows'  => true,
            'post__not_in'   => array( $paint_id ),
        ) );

        $scored = array();
        foreach ( $query->posts as $candidate ) {
            if ( in_array( (int) $candidate->ID, $mapped, true ) ) { continue; }
            $lab = self::hex_to_lab( (string) get_post_meta( $candidate->ID, MPR_Paint_Library::META_HEX, true ) );
            if ( null !== $lab ) { $scored[ (int) $candidate->ID ] = self::delta_e( $source, $lab ); }
        }
        asort( $scored );

        $out = array();
        foreach ( $scored as $id => $delta ) {
            $brand_ids = wp_get_post_terms( $id, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'ids' ) );
            if ( ! empty( $source_brands ) && is_array( $brand_ids ) && array_intersect( $brand_ids, $source_brands ) ) { continue; }

            $out[] = array(
                'id'    => $id,
                'title' => get_the_title( $id ),
                'brand' => implode( ', ', (array) wp_get_post_terms( $id, MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) ) ),
                'hex'   => (string) get_post_meta( $id, MPR_Paint_Library::META_HEX, true ),
                'delta' => round( $delta, 1 ),
            );
            if ( count( $out ) >= $limit ) { break; }
        }
        return $out;
    }

    private function pair_exists( int $a, int $b ): bool {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE ( from_paint_id = %d AND to_paint_id = %d ) OR ( from_paint_id = %d AND to_paint_id = %d )",
                $a,
                $b,
                $b,
                $a
            )
        );
        return $count > 0;
    }
}
