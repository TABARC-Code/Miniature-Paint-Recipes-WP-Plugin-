<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Which library paints a logged-in user owns, and which recipes they can paint with them.
 * Ownership is stored per user as a list of paint library post IDs.
 */
final class MPR_Collection {
	public const USER_META = '_mpr_owned_paints';

	private const MAX_OWNED   = 2000;
	private const MAX_RECIPES = 50;

	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'register_rest' ) );
		add_shortcode( 'paint_recipes_ready', array( $this, 'ready_shortcode' ) );
	}

	/**
	 * @return int[] Paint library IDs the user owns.
	 */
	public static function get_owned( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::USER_META, true );
		if ( ! is_array( $raw ) ) { return array(); }
		return array_values( array_unique( array_filter( array_map( 'absint', $raw ) ) ) );
	}

	public function register_rest(): void {
		register_rest_route( 'mpr/v1', '/owned', array(
			'methods'             => 'POST',
			'permission_callback' => static fn() => is_user_logged_in(),
			'callback'            => array( $this, 'rest_set_owned' ),
			'args'                => array(
				'paint_id' => array( 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ),
				'owned'    => array( 'type' => 'boolean', 'required' => true ),
			),
		) );
	}

	/**
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_set_owned( \WP_REST_Request $req ) {
		$user_id  = get_current_user_id();
		$paint_id = absint( $req->get_param( 'paint_id' ) );
		$owned    = rest_sanitize_boolean( $req->get_param( 'owned' ) );

		$paint = $paint_id > 0 ? get_post( $paint_id ) : null;
		if ( ! $paint || MPR_Paint_Library::CPT !== $paint->post_type || 'publish' !== $paint->post_status ) {
			return new \WP_Error( 'mpr_bad_paint', __( 'That paint does not exist.', 'miniature-paint-recipes' ), array( 'status' => 404 ) );
		}

		$list = self::get_owned( $user_id );
		if ( $owned ) {
			$list[] = $paint_id;
			$list   = array_values( array_unique( $list ) );
			if ( count( $list ) > self::MAX_OWNED ) {
				return new \WP_Error( 'mpr_too_many', __( 'Your collection is full.', 'miniature-paint-recipes' ), array( 'status' => 400 ) );
			}
		} else {
			$list = array_values( array_diff( $list, array( $paint_id ) ) );
		}

		update_user_meta( $user_id, self::USER_META, $list );

		return new \WP_REST_Response( array( 'paint_id' => $paint_id, 'owned' => $owned ), 200 );
	}

	public function ready_shortcode(): string {
		if ( ! is_user_logged_in() ) {
			return '<p class="mpr-ready-note">' . esc_html__( 'Log in to see which recipes you can paint with the paints you own.', 'miniature-paint-recipes' ) . '</p>';
		}

		$user_id = get_current_user_id();
		$owned   = self::get_owned( $user_id );
		if ( empty( $owned ) ) {
			return '<p class="mpr-ready-note">' . esc_html__( 'Tick "I own this" on a recipe card and your paintable recipes will show up here.', 'miniature-paint-recipes' ) . '</p>';
		}

		$pref = MPR_Paint_Library::get_preferred_brand_term_id( $user_id );
		$eq   = new MPR_Equivalents();
		$rows = array();

		$query = new \WP_Query( array(
			'post_type'      => MPR_CPT::CPT,
			'post_status'    => 'publish',
			'posts_per_page' => self::MAX_RECIPES,
			'no_found_rows'  => true,
		) );

		foreach ( $query->posts as $post ) {
			$paints = get_post_meta( $post->ID, MPR_Meta::META_PAINTS, true );
			if ( ! is_array( $paints ) ) { continue; }

			$total = 0;
			$have  = 0;
			foreach ( $paints as $paint ) {
				$lib_id = is_array( $paint ) ? absint( (string) ( $paint['library_id'] ?? '' ) ) : 0;
				if ( $lib_id <= 0 ) { continue; }
				// Same rule as the card: the paint that counts is the preferred-brand equivalent, when one exists.
				if ( $pref > 0 ) {
					$alt = $eq->resolve_preferred_equivalent( $lib_id, $pref );
					if ( $alt > 0 ) { $lib_id = $alt; }
				}
				$total++;
				if ( in_array( $lib_id, $owned, true ) ) { $have++; }
			}
			if ( $total > 0 ) {
				$rows[] = array( 'post' => $post, 'have' => $have, 'total' => $total );
			}
		}

		if ( empty( $rows ) ) {
			return '<p class="mpr-ready-note">' . esc_html__( 'No recipes with linked library paints yet.', 'miniature-paint-recipes' ) . '</p>';
		}

		// Fully covered recipes first, then by share of paints owned.
		usort( $rows, static function ( array $a, array $b ): int {
			$a_ready = $a['have'] === $a['total'];
			$b_ready = $b['have'] === $b['total'];
			if ( $a_ready !== $b_ready ) { return $a_ready ? -1 : 1; }
			return ( $b['have'] / $b['total'] ) <=> ( $a['have'] / $a['total'] );
		} );

		$out = '<ul class="mpr-ready-list">';
		foreach ( $rows as $row ) {
			$ready = $row['have'] === $row['total'];
			$out  .= '<li><a href="' . esc_url( get_permalink( $row['post'] ) ) . '">' . esc_html( get_the_title( $row['post'] ) ) . '</a> &mdash; ';
			$out  .= $ready
				? esc_html__( 'ready to paint', 'miniature-paint-recipes' )
				: esc_html( sprintf( __( '%1$d of %2$d paints owned', 'miniature-paint-recipes' ), $row['have'], $row['total'] ) );
			$out  .= '</li>';
		}
		return $out . '</ul>';
	}
}
