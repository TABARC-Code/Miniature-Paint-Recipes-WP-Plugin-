<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Plugin {
	private static $instance = null;

	/**
	 * WPRM survives because it expects change: migrations, tools, caches, fallbacks.
	 * I’m not cloning it. I’m stealing the survival instincts.
	 */
	private const OPTION_DB_VERSION = 'mpr_db_version';
	private const OPTION_CACHE_SALT = 'mpr_cache_salt';

	// Increment when you change stored data shape.
	private const DB_VERSION = 1;

	// Object cache group.
	private const CACHE_GROUP = 'mpr';

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->hooks();
		$this->bootstrap_safety();
	}

	private function hooks(): void {
		register_activation_hook( MPR_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( MPR_FILE, array( $this, 'deactivate' ) );

		add_action( 'init', array( $this, 'init' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'front_assets' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'block_editor_assets' ) );

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'template_redirect', array( $this, 'maybe_print_view' ) );

		// Cache invalidation hooks.
		add_action( 'save_post', array( $this, 'maybe_purge_cache_on_save' ), 20, 2 );
		add_action( 'deleted_post', array( $this, 'purge_cache_for_post' ), 10, 1 );
	}

	private function bootstrap_safety(): void {
		add_action( 'plugins_loaded', array( $this, 'maybe_run_migrations' ), 2 );
	}

	public function init(): void {
		( new MPR_CPT() )->register();
		( new MPR_Taxonomies() )->register();
		( new MPR_Paint_Library() )->register();
		( new MPR_Equivalents() )->register();
		( new MPR_Meta() )->register();
		( new MPR_Renderer() )->register();
		( new MPR_Block() )->register();

		/**
		 * Extension hook. If you later split “equivalents mapping” into an add-on,
		 * you want a stable hook point that fires when core is ready.
		 */
		do_action( 'mpr_init' );
	}

	public function activate(): void {
		( new MPR_CPT() )->register();
		( new MPR_Taxonomies() )->register();
		( new MPR_Paint_Library() )->register();
		( new MPR_Equivalents() )->register();
		( new MPR_Equivalents() )->maybe_create_table();

		if ( ! get_option( self::OPTION_DB_VERSION ) ) {
			update_option( self::OPTION_DB_VERSION, self::DB_VERSION, false );
		}
		if ( ! get_option( self::OPTION_CACHE_SALT ) ) {
			update_option( self::OPTION_CACHE_SALT, wp_generate_uuid4(), false );
		}

		flush_rewrite_rules();
	}

	public function deactivate(): void {
		flush_rewrite_rules();
	}

	public function maybe_run_migrations(): void {
		$stored = (int) get_option( self::OPTION_DB_VERSION, 0 );

		if ( $stored >= self::DB_VERSION ) {
			return;
		}

		/**
		 * Migration scaffold.
		 * Stage 1: no shape changes yet.
		 * When you evolve meta shape, add migrations here and bump DB_VERSION.
		 */

		update_option( self::OPTION_DB_VERSION, self::DB_VERSION, false );
		$this->purge_all_cache();
	}

	public function admin_assets( string $hook ): void {
		$is_post_screen  = ( $hook === 'post.php' || $hook === 'post-new.php' );
		$is_tools_screen = ( $hook === 'paint-recipes_page_mpr-tools' );

		if ( ! $is_post_screen && ! $is_tools_screen ) {
			return;
		}

		if ( $is_post_screen ) {
			// Media modal for per-step images.
			wp_enqueue_media();
		}


		wp_enqueue_style( 'mpr-admin', MPR_URL . 'assets/css/admin.css', array(), MPR_VERSION );
		wp_enqueue_script( 'mpr-admin', MPR_URL . 'assets/js/admin.js', array( 'jquery' ), MPR_VERSION, true );

		wp_localize_script(
			'mpr-admin',
			'mprAdmin',
			array(
				'nonce'   => wp_create_nonce( 'mpr_admin_nonce' ),
				'restUrl' => esc_url_raw( rest_url() ),
				'strings' => array(
					'remove'    => __( 'Remove', 'miniature-paint-recipes' ),
					'add_paint' => __( 'Add paint', 'miniature-paint-recipes' ),
					'add_step'  => __( 'Add step', 'miniature-paint-recipes' ),
					'select_image' => __( 'Select image', 'miniature-paint-recipes' ),
					'remove_image' => __( 'Remove image', 'miniature-paint-recipes' ),
				),
			)
		);
	}

	public function front_assets(): void {
		wp_enqueue_style( 'mpr-card', MPR_URL . 'assets/css/card.css', array(), MPR_VERSION );
	}

	public function block_editor_assets(): void {
		wp_enqueue_script(
			'mpr-block',
			MPR_URL . 'assets/js/block.js',
			array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-api-fetch' ),
			MPR_VERSION,
			true
		);
	}

	public function admin_menu(): void {
		add_submenu_page(
			'edit.php?post_type=' . MPR_CPT::CPT,
			__( 'Tools', 'miniature-paint-recipes' ),
			__( 'Tools', 'miniature-paint-recipes' ),
			'manage_options',
			'mpr-tools',
			array( $this, 'render_tools_page' )
		);
	}

	public function render_tools_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action = isset( $_POST['mpr_action'] ) ? sanitize_key( (string) $_POST['mpr_action'] ) : '';
		$msg    = '';
		$err    = '';

		if ( $action && check_admin_referer( 'mpr_tools', 'mpr_tools_nonce' ) ) {
			if ( 'purge_cache' === $action ) {
				$this->purge_all_cache();
				$msg = __( 'Cache purged.', 'miniature-paint-recipes' );
			} elseif ( 'export_json' === $action ) {
				$this->tools_export_json();
				return;
			} elseif ( 'import_json' === $action ) {
				$result = $this->tools_import_json();
				if ( is_wp_error( $result ) ) {
					$err = $result->get_error_message();
				} else {
					$msg = sprintf(
						__( 'Imported %d recipe(s).', 'miniature-paint-recipes' ),
						(int) $result
					);
				}
			}
		}

		?>
		<div class="wrap mpr-tools">
			<h1><?php esc_html_e( 'Paint Recipes Tools', 'miniature-paint-recipes' ); ?></h1>

			<?php if ( $msg ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div>
			<?php endif; ?>

			<?php if ( $err ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $err ); ?></p></div>
			<?php endif; ?>

			<p class="description">
				<?php esc_html_e( 'Export/import and cache purge. Not glamorous. The reason your library stays sane.', 'miniature-paint-recipes' ); ?>
			</p>

			<form method="post">
				<?php wp_nonce_field( 'mpr_tools', 'mpr_tools_nonce' ); ?>

				<p>
					<button class="button button-primary" name="mpr_action" value="export_json" type="submit">
						<?php esc_html_e( 'Export JSON', 'miniature-paint-recipes' ); ?>
					</button>

					<button class="button" name="mpr_action" value="purge_cache" type="submit">
						<?php esc_html_e( 'Purge Cache', 'miniature-paint-recipes' ); ?>
					</button>
				</p>

				<hr />

				<h2><?php esc_html_e( 'Import JSON', 'miniature-paint-recipes' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Paste JSON exported by this plugin. If you paste something else, it will refuse. That refusal is kindness.', 'miniature-paint-recipes' ); ?>
				</p>

				<textarea name="mpr_import_json" rows="12" class="large-text code" placeholder='[{"title":"...","status":"draft","subject":"...","scale":"...","paints":[...],"steps":[...]}]'></textarea>

				<p>
					<button class="button button-primary" name="mpr_action" value="import_json" type="submit">
						<?php esc_html_e( 'Import', 'miniature-paint-recipes' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	public function maybe_print_view(): void {
		if ( ! is_singular( MPR_CPT::CPT ) ) { return; }
		if ( ! isset( $_GET['mpr_print'] ) ) { return; }

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) { return; }

		$post = get_post( $post_id );
		if ( ! $post || MPR_CPT::CPT !== $post->post_type ) {
			return;
		}
		if ( 'publish' !== $post->post_status && ! current_user_can( 'read_post', $post_id ) ) {
			status_header( 403 );
			exit;
		}

		$renderer = new MPR_Renderer();
		$html     = $renderer->render_card( $post_id, true );

		status_header( 200 );
		nocache_headers();
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public function maybe_purge_cache_on_save( int $post_id, \WP_Post $post ): void {
		if ( wp_is_post_revision( $post_id ) ) { return; }
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( MPR_CPT::CPT !== $post->post_type ) { return; }

		$this->purge_cache_for_post( $post_id );
	}

	public function purge_cache_for_post( int $post_id ): void {
		wp_cache_delete( 'card:' . $post_id . ':' . self::cache_salt(), self::CACHE_GROUP );
		wp_cache_delete( 'print:' . $post_id . ':' . self::cache_salt(), self::CACHE_GROUP );
	}

	private function purge_all_cache(): void {
		update_option( self::OPTION_CACHE_SALT, wp_generate_uuid4(), false );
	}

	public static function cache_salt(): string {
		$salt = get_option( self::OPTION_CACHE_SALT, '' );
		return is_string( $salt ) && $salt !== '' ? $salt : 'v1';
	}

	private function tools_export_json(): void {
		$q = new \WP_Query( array(
			'post_type'      => MPR_CPT::CPT,
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		) );

		$out = array();

		foreach ( $q->posts as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post ) { continue; }

			$out[] = array(
				'title'   => get_the_title( $post ),
				'status'  => $post->post_status,
				'subject' => (string) get_post_meta( $post_id, MPR_Meta::META_SUBJECT, true ),
				'scale'   => (string) get_post_meta( $post_id, MPR_Meta::META_SCALE, true ),
				'batch_size' => (int) get_post_meta( $post_id, MPR_Meta::META_BATCH_SIZE, true ),
				'profile' => (string) get_post_meta( $post_id, MPR_Meta::META_PROFILE, true ),
				'paints'  => get_post_meta( $post_id, MPR_Meta::META_PAINTS, true ),
				'steps'   => get_post_meta( $post_id, MPR_Meta::META_STEPS, true ),
			);
		}

		$filename = 'mpr-export-' . gmdate( 'Y-m-d-His' ) . '.json';

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		echo wp_json_encode( $out, JSON_PRETTY_PRINT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	private function tools_import_json() {
		$raw = isset( $_POST['mpr_import_json'] ) ? (string) $_POST['mpr_import_json'] : '';
		$raw = trim( wp_unslash( $raw ) );

		if ( $raw === '' ) {
			return new \WP_Error( 'mpr_import_empty', __( 'No JSON provided.', 'miniature-paint-recipes' ) );
		}

		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			return new \WP_Error( 'mpr_import_invalid', __( 'Invalid JSON.', 'miniature-paint-recipes' ) );
		}

		$meta  = new MPR_Meta();
		$count = 0;

		foreach ( $data as $item ) {
			if ( ! is_array( $item ) ) { continue; }

			$title = isset( $item['title'] ) ? sanitize_text_field( (string) $item['title'] ) : '';
			if ( $title === '' ) { continue; }

			$status = isset( $item['status'] ) ? sanitize_key( (string) $item['status'] ) : 'draft';
			if ( ! in_array( $status, array( 'publish', 'draft', 'private' ), true ) ) {
				$status = 'draft';
			}

			$post_id = wp_insert_post( array(
				'post_type'   => MPR_CPT::CPT,
				'post_title'  => $title,
				'post_status' => $status,
			), true );

			if ( is_wp_error( $post_id ) || $post_id <= 0 ) {
				continue;
			}

			update_post_meta( $post_id, MPR_Meta::META_SUBJECT, isset( $item['subject'] ) ? sanitize_text_field( (string) $item['subject'] ) : '' );
			update_post_meta( $post_id, MPR_Meta::META_SCALE,   isset( $item['scale'] ) ? sanitize_text_field( (string) $item['scale'] ) : '' );
			update_post_meta( $post_id, MPR_Meta::META_BATCH_SIZE, isset( $item['batch_size'] ) ? max( 1, (int) $item['batch_size'] ) : 1 );
			$profile = isset( $item['profile'] ) ? sanitize_key( (string) $item['profile'] ) : 'infantry';
			if ( ! array_key_exists( $profile, MPR_Meta::model_profiles() ) ) { $profile = 'infantry'; }
			update_post_meta( $post_id, MPR_Meta::META_PROFILE, $profile );

			$paints = isset( $item['paints'] ) && is_array( $item['paints'] ) ? $item['paints'] : array();
			$steps  = isset( $item['steps'] ) && is_array( $item['steps'] ) ? $item['steps'] : array();

			update_post_meta( $post_id, MPR_Meta::META_PAINTS, $meta->sanitize_repeater_array( $paints, 'paint' ) );
			update_post_meta( $post_id, MPR_Meta::META_STEPS,  $meta->sanitize_repeater_array( $steps,  'step' ) );

			$this->purge_cache_for_post( (int) $post_id );
			$count++;
		}

		return $count;
	}
}
