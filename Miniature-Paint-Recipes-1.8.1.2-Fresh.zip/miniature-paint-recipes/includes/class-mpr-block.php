<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Block {
	public function register(): void {
		add_action( 'init', array( $this, 'init_block' ) );
	}

	public function init_block(): void {
		if ( ! function_exists( 'register_block_type' ) ) { return; }

		register_block_type(
			'mpr/paint-recipe',
			array(
				'api_version'     => 2,
				'title'           => __( 'Paint Recipe Card', 'miniature-paint-recipes' ),
				'category'        => 'widgets',
				'icon'            => 'art',
				'description'     => __( 'Renders a paint recipe card from a Paint Recipe post.', 'miniature-paint-recipes' ),
				'attributes'      => array(
					'id'    => array( 'type' => 'number',  'default' => 0 ),
					'print' => array( 'type' => 'boolean', 'default' => false ),
				),
				'render_callback' => array( $this, 'render' ),
			)
		);
	}

	public function render( array $attributes ): string {
		$id    = isset( $attributes['id'] ) ? (int) $attributes['id'] : 0;
		$print = ! empty( $attributes['print'] );

		if ( $id <= 0 ) {
			return '<p class="mpr-block-placeholder">' . esc_html__( 'Select a Paint Recipe to render.', 'miniature-paint-recipes' ) . '</p>';
		}

		return ( new MPR_Renderer() )->render_card( $id, $print );
	}
}
