<?php
namespace MiniaturePaintRecipes;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class MPR_Meta {
	public const META_SUBJECT    = '_mpr_subject';
	public const META_SCALE      = '_mpr_scale';
	public const META_BATCH_SIZE = '_mpr_batch_size';
	public const META_PROFILE    = '_mpr_profile';
	public const META_PAINTS     = '_mpr_paints';
	public const META_STEPS      = '_mpr_steps';

	public function register(): void {
		add_action( 'add_meta_boxes', array( $this, 'meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save' ), 10, 2 );
		add_action( 'init', array( $this, 'register_meta_rest' ) );
	}

	public static function model_profiles(): array {
		return array(
			'infantry' => array( 'label' => __( 'Infantry', 'miniature-paint-recipes' ), 'multiplier' => 1 ),
			'character' => array( 'label' => __( 'Character / Elite', 'miniature-paint-recipes' ), 'multiplier' => 2 ),
			'large' => array( 'label' => __( 'Large Model / Monster', 'miniature-paint-recipes' ), 'multiplier' => 5 ),
			'vehicle' => array( 'label' => __( 'Vehicle / Tank', 'miniature-paint-recipes' ), 'multiplier' => 15 ),
		);
	}

	public function meta_boxes(): void {
		add_meta_box(
			'mpr_recipe_details',
			__( 'Paint Recipe Details', 'miniature-paint-recipes' ),
			array( $this, 'render_box' ),
			MPR_CPT::CPT,
			'normal',
			'high'
		);
	}

	public function render_box( \WP_Post $post ): void {
		wp_nonce_field( 'mpr_save_meta', 'mpr_meta_nonce' );

		$subject    = (string) get_post_meta( $post->ID, self::META_SUBJECT, true );
		$scale      = (string) get_post_meta( $post->ID, self::META_SCALE, true );
		$batch_size = (int) get_post_meta( $post->ID, self::META_BATCH_SIZE, true );
		$profile    = (string) get_post_meta( $post->ID, self::META_PROFILE, true );
		$paints     = get_post_meta( $post->ID, self::META_PAINTS, true );
		$steps      = get_post_meta( $post->ID, self::META_STEPS, true );

		if ( $batch_size <= 0 ) { $batch_size = 1; }
		if ( ! array_key_exists( $profile, self::model_profiles() ) ) { $profile = 'infantry'; }
		if ( ! is_array( $paints ) ) { $paints = array(); }
		if ( ! is_array( $steps ) )  { $steps = array(); }

		foreach ( $paints as $idx => $paint ) {
			if ( empty( $paint['id'] ) ) {
				$paints[ $idx ]['id'] = wp_generate_uuid4();
			}
		}
		?>
		<div class="mpr-box">
			<div class="mpr-grid mpr-grid--meta">
				<p class="mpr-row mpr-wide">
					<label for="mpr_subject"><strong><?php esc_html_e( 'Subject', 'miniature-paint-recipes' ); ?></strong></label>
					<input type="text" id="mpr_subject" name="mpr_subject" value="<?php echo esc_attr( $subject ); ?>" class="widefat"
						placeholder="e.g. Intercessor, Goff Ork Boy, Leman Russ hull" />
				</p>

				<p class="mpr-row">
					<label for="mpr_scale"><strong><?php esc_html_e( 'Scale', 'miniature-paint-recipes' ); ?></strong></label>
					<input type="text" id="mpr_scale" name="mpr_scale" value="<?php echo esc_attr( $scale ); ?>" class="widefat"
						placeholder="e.g. 28mm, 32mm heroic, 1/35" />
				</p>

				<p class="mpr-row">
					<label for="mpr_batch_size"><strong><?php esc_html_e( 'Batch Size', 'miniature-paint-recipes' ); ?></strong></label>
					<input type="number" min="1" step="1" id="mpr_batch_size" name="mpr_batch_size" value="<?php echo esc_attr( (string) $batch_size ); ?>" class="widefat" />
					<span class="description"><?php esc_html_e( 'The number of matching miniatures covered by the recorded paint quantities. No size multipliers are applied.', 'miniature-paint-recipes' ); ?></span>
				</p>

				<input type="hidden" name="mpr_profile" value="<?php echo esc_attr( $profile ); ?>" />
			</div>

			<div class="mpr-section">
				<div class="mpr-section-head">
					<h3><?php esc_html_e( 'Paint stack', 'miniature-paint-recipes' ); ?></h3>
					<div class="mpr-section-head__actions">
						<input type="search" id="mpr-paint-filter" class="mpr-filter" placeholder="<?php esc_attr_e( 'Filter paints…', 'miniature-paint-recipes' ); ?>" />
						<button type="button" class="button mpr-filter-clear"><?php esc_html_e( 'Clear', 'miniature-paint-recipes' ); ?></button>
						<button type="button" class="button mpr-add-paint"><?php esc_html_e( 'Add paint', 'miniature-paint-recipes' ); ?></button>
					</div>
				</div>

				<p class="description"><?php esc_html_e( 'Each row can link to the global paint library and carry its own calculator numbers. That way “Abaddon Black” is one thing globally, but used differently in different schemes.', 'miniature-paint-recipes' ); ?></p>

				<div id="mpr-paints" class="mpr-repeater" data-name="mpr_paints">
					<?php foreach ( $paints as $idx => $paint ) : ?>
						<?php $this->paint_row( (int) $idx, (array) $paint ); ?>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="mpr-section">
				<div class="mpr-section-head">
					<h3><?php esc_html_e( 'Steps', 'miniature-paint-recipes' ); ?></h3>
					<button type="button" class="button mpr-add-step"><?php esc_html_e( 'Add step', 'miniature-paint-recipes' ); ?></button>
				</div>

				<p class="description"><?php esc_html_e( 'Steps can now link to actual paint rows. Good. Comma-separated guesses were getting embarrassing.', 'miniature-paint-recipes' ); ?></p>

				<div id="mpr-steps" class="mpr-repeater" data-name="mpr_steps">
					<?php foreach ( $steps as $idx => $step ) : ?>
						<?php $this->step_row( (int) $idx, (array) $step, $paints ); ?>
					<?php endforeach; ?>
				</div>
			</div>

			<input type="hidden" id="mpr-paints-json" name="mpr_paints_json" value="<?php echo esc_attr( wp_json_encode( $paints ) ); ?>" />
			<input type="hidden" id="mpr-steps-json" name="mpr_steps_json" value="<?php echo esc_attr( wp_json_encode( $steps ) ); ?>" />
		</div>
		<?php
	}

	private function paint_row( int $idx, array $paint ): void {
		$defaults = array(
			'id'          => wp_generate_uuid4(),
			'library_id'  => '',
			'role'        => '',
			'brand'       => '',
			'range'       => '',
			'name'        => '',
			'code'        => '',
			'hex'         => '',
			'mix'         => '',
			'notes'       => '',
			'calc_amount' => '',
			'calc_unit'   => 'drops',
		);
		$paint = array_merge( $defaults, $paint );
		?>
		<div class="mpr-item mpr-paint" data-index="<?php echo esc_attr( (string) $idx ); ?>" data-paint-id="<?php echo esc_attr( (string) $paint['id'] ); ?>">
			<div class="mpr-grid">
				<input type="hidden" class="mpr-field" data-field="id" value="<?php echo esc_attr( (string) $paint['id'] ); ?>" />
				<div class="mpr-paint-linker mpr-wide">
					<input type="text" class="mpr-field" data-field="library_id" value="<?php echo esc_attr( (string) $paint['library_id'] ); ?>" placeholder="<?php esc_attr_e( 'Linked library paint ID (optional)', 'miniature-paint-recipes' ); ?>" />
					<button type="button" class="button mpr-link-paint"><?php esc_html_e( 'Find in library', 'miniature-paint-recipes' ); ?></button>
					<span class="description"><?php esc_html_e( 'Optional, but it unlocks equivalents and keeps names sane.', 'miniature-paint-recipes' ); ?></span>
				</div>
				<input type="text" class="mpr-field" data-field="role" value="<?php echo esc_attr( (string) $paint['role'] ); ?>" placeholder="role (primer/base/shade/highlight/varnish/effect)" />
				<input type="text" class="mpr-field" data-field="brand" value="<?php echo esc_attr( (string) $paint['brand'] ); ?>" placeholder="brand" />
				<input type="text" class="mpr-field" data-field="range" value="<?php echo esc_attr( (string) $paint['range'] ); ?>" placeholder="range" />
				<input type="text" class="mpr-field" data-field="name" value="<?php echo esc_attr( (string) $paint['name'] ); ?>" placeholder="paint name" />
				<input type="text" class="mpr-field" data-field="code" value="<?php echo esc_attr( (string) $paint['code'] ); ?>" placeholder="code (optional)" />
				<input type="text" class="mpr-field mpr-hex" data-field="hex" value="<?php echo esc_attr( (string) $paint['hex'] ); ?>" placeholder="#rrggbb (optional)" />
				<input type="text" class="mpr-field" data-field="mix" value="<?php echo esc_attr( (string) $paint['mix'] ); ?>" placeholder="mix / thinning notes" />
				<input type="text" class="mpr-field mpr-wide" data-field="notes" value="<?php echo esc_attr( (string) $paint['notes'] ); ?>" placeholder="notes (coverage, substitute, finish)" />
				<input type="number" min="0" step="0.01" class="mpr-field" data-field="calc_amount" value="<?php echo esc_attr( (string) $paint['calc_amount'] ); ?>" placeholder="calc amount per model" />
				<select class="mpr-field" data-field="calc_unit">
					<?php foreach ( array( 'drops', 'ml', 'pots', 'cans' ) as $unit ) : ?>
						<option value="<?php echo esc_attr( $unit ); ?>" <?php selected( (string) $paint['calc_unit'], $unit ); ?>><?php echo esc_html( ucfirst( $unit ) ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<button type="button" class="button-link mpr-remove"><?php esc_html_e( 'Remove', 'miniature-paint-recipes' ); ?></button>
		</div>
		<?php
	}

	private function step_row( int $idx, array $step, array $paints ): void {
		$defaults = array(
			'group'          => '',
			'title'          => '',
			'body'           => '',
			'paints'         => '',
			'paints_used'    => array(),
			'techniques'     => '',
			'time'           => '',
			'media_id'       => '',
		);
		$step = array_merge( $defaults, $step );
		if ( ! is_array( $step['paints_used'] ) ) {
			$step['paints_used'] = array();
		}
		$media_id = absint( (string) $step['media_id'] );
		$thumb    = $media_id ? wp_get_attachment_image( $media_id, 'thumbnail', false, array( 'class' => 'mpr-media__img' ) ) : '';
		?>
		<div class="mpr-item mpr-step" data-index="<?php echo esc_attr( (string) $idx ); ?>">
			<div class="mpr-grid">
				<input type="text" class="mpr-field" data-field="group" value="<?php echo esc_attr( (string) $step['group'] ); ?>" placeholder="group (Prep, Base, Wash, Finish…)" />
				<input type="text" class="mpr-field mpr-wide" data-field="title" value="<?php echo esc_attr( (string) $step['title'] ); ?>" placeholder="step title" />
				<textarea class="mpr-field mpr-wide" data-field="body" rows="3" placeholder="what you actually did (pressure, thinning, brush size, intent)"><?php echo esc_textarea( (string) $step['body'] ); ?></textarea>
				<input type="text" class="mpr-field" data-field="paints" value="<?php echo esc_attr( (string) $step['paints'] ); ?>" placeholder="legacy paint text (optional)" />
				<input type="hidden" class="mpr-field" data-field="paints_used_json" value="<?php echo esc_attr( wp_json_encode( array_values( $step['paints_used'] ) ) ); ?>" />
				<div class="mpr-step-paints mpr-wide">
					<label><strong><?php esc_html_e( 'Linked paints used', 'miniature-paint-recipes' ); ?></strong></label>
					<select class="mpr-step-paints-select" multiple size="4">
						<?php foreach ( $paints as $paint ) : ?>
							<?php if ( ! is_array( $paint ) ) { continue; } ?>
							<?php $pid = (string) ( $paint['id'] ?? '' ); if ( '' === $pid ) { continue; } ?>
							<?php $plabel = trim( implode( ' ', array_filter( array( (string) ( $paint['brand'] ?? '' ), (string) ( $paint['name'] ?? '' ) ) ) ) ); ?>
							<option value="<?php echo esc_attr( $pid ); ?>" <?php selected( in_array( $pid, array_values( $step['paints_used'] ), true ) ); ?>><?php echo esc_html( $plabel !== '' ? $plabel : $pid ); ?></option>
						<?php endforeach; ?>
					</select>
					<span class="description"><?php esc_html_e( 'Hold Ctrl/Cmd to select more than one. Yes, it is still WordPress. No, I do not make the rules.', 'miniature-paint-recipes' ); ?></span>
				</div>
				<input type="text" class="mpr-field" data-field="techniques" value="<?php echo esc_attr( (string) $step['techniques'] ); ?>" placeholder="techniques (comma list)" />
				<input type="text" class="mpr-field" data-field="time" value="<?php echo esc_attr( (string) $step['time'] ); ?>" placeholder="time (optional; e.g. 10m, 1h dry)" />
				<div class="mpr-media" data-mpr-media="1">
					<input type="hidden" class="mpr-field" data-field="media_id" value="<?php echo esc_attr( (string) $media_id ); ?>" />
					<div class="mpr-media__preview">
						<?php if ( $thumb ) : ?>
							<?php echo $thumb; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php else : ?>
							<span class="mpr-media__empty"><?php esc_html_e( 'No step image', 'miniature-paint-recipes' ); ?></span>
						<?php endif; ?>
					</div>
					<button type="button" class="button mpr-media-select"><?php esc_html_e( 'Select image', 'miniature-paint-recipes' ); ?></button>
					<button type="button" class="button mpr-media-remove"><?php esc_html_e( 'Remove image', 'miniature-paint-recipes' ); ?></button>
				</div>
			</div>
			<button type="button" class="button-link mpr-remove"><?php esc_html_e( 'Remove', 'miniature-paint-recipes' ); ?></button>
		</div>
		<?php
	}

	public function save( int $post_id, \WP_Post $post ): void {
		if ( MPR_CPT::CPT !== $post->post_type ) { return; }
		if ( wp_is_post_revision( $post_id ) ) { return; }
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( ! isset( $_POST['mpr_meta_nonce'] ) || ! wp_verify_nonce( (string) $_POST['mpr_meta_nonce'], 'mpr_save_meta' ) ) { return; }
		if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

		$subject    = isset( $_POST['mpr_subject'] ) ? sanitize_text_field( (string) $_POST['mpr_subject'] ) : '';
		$scale      = isset( $_POST['mpr_scale'] ) ? sanitize_text_field( (string) $_POST['mpr_scale'] ) : '';
		$batch_size = isset( $_POST['mpr_batch_size'] ) ? max( 1, (int) $_POST['mpr_batch_size'] ) : 1;
		$profile    = isset( $_POST['mpr_profile'] ) ? sanitize_key( (string) $_POST['mpr_profile'] ) : 'infantry';
		if ( ! array_key_exists( $profile, self::model_profiles() ) ) { $profile = 'infantry'; }

		update_post_meta( $post_id, self::META_SUBJECT, $subject );
		update_post_meta( $post_id, self::META_SCALE, $scale );
		update_post_meta( $post_id, self::META_BATCH_SIZE, $batch_size );
		update_post_meta( $post_id, self::META_PROFILE, $profile );

		$paints = $this->decode_json_meta( isset( $_POST['mpr_paints_json'] ) ? (string) $_POST['mpr_paints_json'] : '' );
		$steps  = $this->decode_json_meta( isset( $_POST['mpr_steps_json'] ) ? (string) $_POST['mpr_steps_json'] : '' );

		$sanitised_paints = $this->sanitize_repeater_array( $paints, 'paint' );
		$allowed_ids = array();
		foreach ( $sanitised_paints as $paint ) {
			$allowed_ids[] = (string) $paint['id'];
		}
		$sanitised_steps = $this->sanitize_repeater_array( $steps, 'step', $allowed_ids );

		update_post_meta( $post_id, self::META_PAINTS, $sanitised_paints );
		update_post_meta( $post_id, self::META_STEPS, $sanitised_steps );
	}

	private function decode_json_meta( string $raw ) : array {
		$raw = trim( wp_unslash( $raw ) );
		if ( '' === $raw ) { return array(); }
		$data = json_decode( $raw, true );
		return is_array( $data ) ? $data : array();
	}

	public function sanitize_repeater_array( array $data, string $type, array $allowed_paint_ids = array() ): array {
		$clean = array();

		foreach ( $data as $row ) {
			if ( ! is_array( $row ) ) { continue; }

			if ( 'paint' === $type ) {
				$out = array(
					'id'          => sanitize_text_field( (string) ( $row['id'] ?? '' ) ),
					'library_id'  => (string) absint( (string) ( $row['library_id'] ?? '' ) ),
					'role'        => sanitize_text_field( (string) ( $row['role'] ?? '' ) ),
					'brand'       => sanitize_text_field( (string) ( $row['brand'] ?? '' ) ),
					'range'       => sanitize_text_field( (string) ( $row['range'] ?? '' ) ),
					'name'        => sanitize_text_field( (string) ( $row['name'] ?? '' ) ),
					'code'        => sanitize_text_field( (string) ( $row['code'] ?? '' ) ),
					'hex'         => $this->sanitize_hex_colour( (string) ( $row['hex'] ?? '' ) ),
					'mix'         => sanitize_text_field( (string) ( $row['mix'] ?? '' ) ),
					'notes'       => sanitize_text_field( (string) ( $row['notes'] ?? '' ) ),
					'calc_amount' => $this->sanitize_decimal_string( (string) ( $row['calc_amount'] ?? '' ) ),
					'calc_unit'   => sanitize_key( (string) ( $row['calc_unit'] ?? 'drops' ) ),
				);
				if ( '' === $out['id'] ) { $out['id'] = wp_generate_uuid4(); }
				if ( ! in_array( $out['calc_unit'], array( 'drops', 'ml', 'pots', 'cans' ), true ) ) { $out['calc_unit'] = 'drops'; }
				if ( trim( $out['role'] . $out['brand'] . $out['range'] . $out['name'] . $out['mix'] . $out['notes'] . $out['library_id'] ) === '' ) { continue; }
				$clean[] = $out;
				continue;
			}

			if ( 'step' === $type ) {
				$paints_used = array();
				$raw_ids = $row['paints_used_json'] ?? ( $row['paints_used'] ?? array() );
				if ( is_string( $raw_ids ) ) {
					$decoded = json_decode( $raw_ids, true );
					$raw_ids = is_array( $decoded ) ? $decoded : preg_split( '/\s*,\s*/', $raw_ids, -1, PREG_SPLIT_NO_EMPTY );
				}
				if ( is_array( $raw_ids ) ) {
					foreach ( $raw_ids as $id ) {
						$id = sanitize_text_field( (string) $id );
						if ( in_array( $id, $allowed_paint_ids, true ) ) {
							$paints_used[] = $id;
						}
					}
				}

				$out = array(
					'group'       => sanitize_text_field( (string) ( $row['group'] ?? '' ) ),
					'title'       => sanitize_text_field( (string) ( $row['title'] ?? '' ) ),
					'body'        => sanitize_textarea_field( (string) ( $row['body'] ?? '' ) ),
					'paints'      => sanitize_text_field( (string) ( $row['paints'] ?? '' ) ),
					'paints_used' => array_values( array_unique( $paints_used ) ),
					'techniques'  => sanitize_text_field( (string) ( $row['techniques'] ?? '' ) ),
					'time'        => sanitize_text_field( (string) ( $row['time'] ?? '' ) ),
					'media_id'    => (string) absint( (string) ( $row['media_id'] ?? '' ) ),
				);
				if ( trim( $out['title'] . $out['body'] . $out['group'] ) === '' ) { continue; }
				$clean[] = $out;
			}
		}

		return $clean;
	}

	private function sanitize_hex_colour( string $hex ): string {
		$hex = trim( $hex );
		if ( '' === $hex ) { return ''; }
		return preg_match( '/^#[0-9a-fA-F]{6}$/', $hex ) ? strtolower( $hex ) : '';
	}

	private function sanitize_decimal_string( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) { return ''; }
		$value = str_replace( ',', '.', $value );
		return preg_match( '/^\d+(\.\d+)?$/', $value ) ? $value : '';
	}

	public function register_meta_rest(): void {
		$scalar_args = array(
			'type'         => 'string',
			'single'       => true,
			'show_in_rest' => true,
			'auth_callback'=> static function () { return current_user_can( 'edit_posts' ); },
		);

		register_post_meta( MPR_CPT::CPT, self::META_SUBJECT, $scalar_args );
		register_post_meta( MPR_CPT::CPT, self::META_SCALE, $scalar_args );
		register_post_meta( MPR_CPT::CPT, self::META_BATCH_SIZE, array_merge( $scalar_args, array( 'type' => 'integer' ) ) );
		register_post_meta( MPR_CPT::CPT, self::META_PROFILE, $scalar_args );

		register_post_meta(
			MPR_CPT::CPT,
			self::META_PAINTS,
			array(
				'type'         => 'array',
				'single'       => true,
				'show_in_rest' => array( 'schema' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ),
				'auth_callback'=> static function () { return current_user_can( 'edit_posts' ); },
			)
		);

		register_post_meta(
			MPR_CPT::CPT,
			self::META_STEPS,
			array(
				'type'         => 'array',
				'single'       => true,
				'show_in_rest' => array( 'schema' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ),
				'auth_callback'=> static function () { return current_user_can( 'edit_posts' ); },
			)
		);
	}
}
