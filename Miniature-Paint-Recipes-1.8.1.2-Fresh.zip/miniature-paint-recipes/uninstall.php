<?php
/**
 * Uninstall script.
 * I delete only what we created. No “mystery nukes”.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }


// Delete posts we own.
$post_types = array( 'mpr_paint_recipe', 'mpr_paint' );

foreach ( $post_types as $post_type ) {
	$ids = get_posts( array(
		'post_type'      => $post_type,
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	) );

	foreach ( $ids as $post_id ) {
		wp_delete_post( (int) $post_id, true );
	}
}

// Drop our equivalents table.
global $wpdb;
$table = $wpdb->prefix . 'mpr_paint_equivalents';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );

// Delete user preferences.
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key = '_mpr_preferred_brand_term'" );

delete_option( 'mpr_db_version' );
delete_option( 'mpr_cache_salt' );
