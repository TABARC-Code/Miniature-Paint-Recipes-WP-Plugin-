<?php
/**
 * Plugin Name: Miniature Paint Recipes
 * Plugin URI: https://github.com/TABARC-Code/
 * Description: Structured paint recipes + step-by-step miniature tutorials as reusable cards (paints, mixes, techniques, steps, print view).
 * Version: 1.8.1.2
 * Author: TABARC-Code
 * Author URI: https://github.com/TABARC-Code/
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: miniature-paint-recipes
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * The only “global” I like is a constant.
 * WordPress is timing-sensitive and full of shared state.
 * Constants keep me from lying to myself about what exists.
 */
define( 'MPR_VERSION', '1.8.1.2' );
define( 'MPR_FILE', __FILE__ );
define( 'MPR_DIR', plugin_dir_path( __FILE__ ) );
define( 'MPR_URL', plugin_dir_url( __FILE__ ) );

require_once MPR_DIR . 'includes/class-mpr-plugin.php';
require_once MPR_DIR . 'includes/class-mpr-cpt.php';
require_once MPR_DIR . 'includes/class-mpr-meta.php';
require_once MPR_DIR . 'includes/class-mpr-renderer.php';
require_once MPR_DIR . 'includes/class-mpr-schema.php';
require_once MPR_DIR . 'includes/class-mpr-block.php';
require_once MPR_DIR . 'includes/class-mpr-taxonomies.php';
require_once MPR_DIR . 'includes/class-mpr-paint-library.php';
require_once MPR_DIR . 'includes/class-mpr-equivalents.php';

add_action( 'plugins_loaded', static function () {
	\MiniaturePaintRecipes\MPR_Plugin::instance();
}, 1 );
