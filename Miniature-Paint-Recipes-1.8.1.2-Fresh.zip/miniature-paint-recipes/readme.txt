=== Miniature Paint Recipes ===
Contributors: tabarc-code
Tags: miniature painting, tutorials, paints, hobby
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.8.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Structured paint recipes and step-by-step miniature tutorials as reusable cards.

== Description ==
Miniature Paint Recipes creates a Paint Recipe post type and a renderable card that contains:
- Subject + scale metadata
- Paint stack (brand, range, name, role, mix, notes, optional swatch)
- Ordered steps (title, method, paints used, techniques, time)

Includes:
- Shortcode: [paint_recipe id="123"]
- Dynamic block: “Paint Recipe Card”
- Print view: ?mpr_print=1
- JSON-LD HowTo schema output
- Tools page for JSON export/import and cache purge

== Installation ==
1. Upload to /wp-content/plugins/miniature-paint-recipes/
2. Activate in Plugins
3. Create a Paint Recipe
4. Render via shortcode or block

== Changelog ==
= 1.6.1.3 =
Reworked Stage 1: platform init hook, migrations scaffold, cache salt, fallback rendering, safer templates, stricter import.
