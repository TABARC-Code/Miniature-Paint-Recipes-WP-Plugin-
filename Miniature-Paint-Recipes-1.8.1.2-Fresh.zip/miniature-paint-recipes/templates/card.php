<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$meta_line  = trim( $subject . ( $subject && $scale ? ' | ' : '' ) . $scale );
$batch_size = (int) get_post_meta( $post->ID, \MiniaturePaintRecipes\MPR_Meta::META_BATCH_SIZE, true );
$profile    = (string) get_post_meta( $post->ID, \MiniaturePaintRecipes\MPR_Meta::META_PROFILE, true );
$profiles   = \MiniaturePaintRecipes\MPR_Meta::model_profiles();
if ( $batch_size <= 0 ) { $batch_size = 1; }
if ( ! isset( $profiles[ $profile ] ) ) { $profile = 'infantry'; }
$profile_cfg = $profiles[ $profile ];

$resolve_paint = static function( array $paint ): array {
	$lib_id = absint( (string) ( $paint['library_id'] ?? '' ) );
	if ( $lib_id > 0 && is_user_logged_in() ) {
		$pref = \MiniaturePaintRecipes\MPR_Paint_Library::get_preferred_brand_term_id( get_current_user_id() );
		if ( $pref > 0 ) {
			$eq_id = ( new \MiniaturePaintRecipes\MPR_Equivalents() )->resolve_preferred_equivalent( $lib_id, $pref );
			if ( $eq_id > 0 ) { $lib_id = $eq_id; }
		}
		$title = get_the_title( $lib_id );
		if ( $title ) { $paint['name'] = $title; }
		$paint['brand'] = implode( ', ', (array) wp_get_post_terms( $lib_id, \MiniaturePaintRecipes\MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) ) );
		$paint['range'] = implode( ', ', (array) wp_get_post_terms( $lib_id, \MiniaturePaintRecipes\MPR_Taxonomies::TAX_RANGE, array( 'fields' => 'names' ) ) );
		$hex_meta = (string) get_post_meta( $lib_id, '_mpr_paint_hex', true );
		if ( $hex_meta ) { $paint['hex'] = $hex_meta; }
		$code_meta = (string) get_post_meta( $lib_id, '_mpr_paint_code', true );
		if ( $code_meta ) { $paint['code'] = $code_meta; }
	}
	$paint['label'] = trim( implode( ' ', array_filter( array( (string) ( $paint['brand'] ?? '' ), (string) ( $paint['range'] ?? '' ), (string) ( $paint['name'] ?? '' ) ) ) ) );
	return $paint;
};

$paints_by_id = array();
$groups = array();
$calculator_rows = array();
foreach ( $paints as $p ) {
	if ( ! is_array( $p ) ) { continue; }
	$p = $resolve_paint( $p );
	$pid = (string) ( $p['id'] ?? '' );
	if ( $pid !== '' ) { $paints_by_id[ $pid ] = $p; }
	$role = trim( (string) ( $p['role'] ?? '' ) );
	$key = $role !== '' ? strtolower( $role ) : 'paints';
	if ( ! isset( $groups[ $key ] ) ) {
		$groups[ $key ] = array( 'label' => $role !== '' ? $role : __( 'Paints', 'miniature-paint-recipes' ), 'items' => array() );
	}
	$groups[ $key ]['items'][] = $p;
	$calc_amount = isset( $p['calc_amount'] ) ? (float) $p['calc_amount'] : 0.0;
	if ( $calc_amount > 0 ) {
		$calculator_rows[] = array(
			'id' => $pid,
			'label' => $p['label'] !== '' ? $p['label'] : __( 'Unnamed paint', 'miniature-paint-recipes' ),
			'unit' => (string) ( $p['calc_unit'] ?? 'drops' ),
			'amount' => $calc_amount,
			'role' => $role,
		);
	}
}

$grouped_steps = array();
foreach ( $steps as $idx => $step ) {
	if ( ! is_array( $step ) ) { continue; }
	$title = trim( (string) ( $step['title'] ?? '' ) );
	$body  = trim( (string) ( $step['body'] ?? '' ) );
	$group = trim( (string) ( $step['group'] ?? '' ) );
	if ( $title === '' && $body === '' && $group === '' ) { continue; }
	$gkey = $group !== '' ? $group : __( 'Steps', 'miniature-paint-recipes' );
	if ( ! isset( $grouped_steps[ $gkey ] ) ) { $grouped_steps[ $gkey ] = array(); }
	$grouped_steps[ $gkey ][] = $step;
}
?>
<div class="mpr-card" data-mpr="card" data-mpr-recipe-id="<?php echo esc_attr( (string) $post->ID ); ?>">
	<div class="mpr-card__head" id="mpr-top-<?php echo esc_attr( (string) $post->ID ); ?>">
		<h2 class="mpr-card__title"><?php echo esc_html( get_the_title( $post ) ); ?></h2>

		<?php if ( $meta_line ) : ?>
			<p class="mpr-card__meta"><?php echo esc_html( $meta_line ); ?></p>
		<?php endif; ?>

		<div class="mpr-card__actions">
			<a class="mpr-card__button" href="<?php echo esc_url( add_query_arg( array( 'mpr_print' => 1 ), get_permalink( $post ) ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Print', 'miniature-paint-recipes' ); ?></a>
			<span class="mpr-card__hint"><?php echo esc_html( sprintf( __( 'Recipe baseline: %d matching miniatures', 'miniature-paint-recipes' ), $batch_size ) ); ?></span>
		</div>
	</div>

	<div class="mpr-toolbar" data-mpr-toolbar>
		<a href="#mpr-paints-<?php echo esc_attr( (string) $post->ID ); ?>" class="mpr-pill"><?php esc_html_e( 'Jump to paints', 'miniature-paint-recipes' ); ?></a>
		<a href="#mpr-steps-<?php echo esc_attr( (string) $post->ID ); ?>" class="mpr-pill"><?php esc_html_e( 'Jump to steps', 'miniature-paint-recipes' ); ?></a>
		<button type="button" class="mpr-pill mpr-copy-shortcode"><?php esc_html_e( 'Copy shortcode', 'miniature-paint-recipes' ); ?></button>
		<button type="button" class="mpr-pill mpr-copy-paints"><?php esc_html_e( 'Copy paints', 'miniature-paint-recipes' ); ?></button>
		<button type="button" class="mpr-pill mpr-copy-steps"><?php esc_html_e( 'Copy steps', 'miniature-paint-recipes' ); ?></button>
		<button type="button" class="mpr-pill mpr-toggle-steps"><?php esc_html_e( 'Collapse steps', 'miniature-paint-recipes' ); ?></button>
		<span class="mpr-toolbar__status" aria-live="polite"></span>
	</div>

	<?php if ( ! empty( $calculator_rows ) ) : ?>
		<section class="mpr-card__section mpr-calculator" data-mpr-calculator='<?php echo esc_attr( wp_json_encode( array(
			'batchSize' => $batch_size,
			'multiplier' => 1,
			'rows' => $calculator_rows,
		) ) ); ?>'>
			<h3><?php esc_html_e( 'Paint Calculator', 'miniature-paint-recipes' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Estimator, not prophecy. It scales your recorded usage per model and converts drops into ml/pots where useful.', 'miniature-paint-recipes' ); ?></p>
			<div class="mpr-calculator__controls">
				<label>
					<span><?php esc_html_e( 'Models to paint', 'miniature-paint-recipes' ); ?></span>
					<input type="number" min="1" max="100000" step="1" class="mpr-calculator__input" value="<?php echo esc_attr( (string) $batch_size ); ?>" />
				</label>
				<div class="mpr-calculator__assumption"><?php esc_html_e( 'Quantities are estimates for the same miniature type.', 'miniature-paint-recipes' ); ?></div>
			</div>
			<ul class="mpr-calculator__list"></ul>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $groups ) ) : ?>
		<section class="mpr-card__section" id="mpr-paints-<?php echo esc_attr( (string) $post->ID ); ?>">
			<h3><?php esc_html_e( 'Paint stack', 'miniature-paint-recipes' ); ?></h3>
			<?php foreach ( $groups as $g ) : ?>
				<div class="mpr-paint-group">
					<h4 class="mpr-paint-group__title"><?php echo esc_html( $g['label'] ); ?></h4>
					<ul class="mpr-paint-list">
						<?php foreach ( $g['items'] as $paint ) : ?>
							<?php
							$label = (string) ( $paint['label'] ?? '' );
							$code  = trim( (string) ( $paint['code'] ?? '' ) );
							$hex   = trim( (string) ( $paint['hex'] ?? '' ) );
							$mix   = trim( (string) ( $paint['mix'] ?? '' ) );
							$notes = trim( (string) ( $paint['notes'] ?? '' ) );
							?>
							<li class="mpr-paint">
								<?php if ( $hex ) : ?>
									<span class="mpr-swatch" style="background: <?php echo esc_attr( $hex ); ?>" title="<?php echo esc_attr( $hex ); ?>"></span>
								<?php else : ?>
									<span class="mpr-swatch mpr-swatch--empty" title="<?php esc_attr_e( 'No swatch', 'miniature-paint-recipes' ); ?>"></span>
								<?php endif; ?>
								<div class="mpr-paint__main">
									<div class="mpr-paint__name"><?php echo esc_html( $label !== '' ? $label : __( 'Unnamed paint', 'miniature-paint-recipes' ) ); ?><?php if ( $code ) : ?><span class="mpr-paint__code"><?php echo esc_html( $code ); ?></span><?php endif; ?></div>
									<?php if ( $mix || $notes ) : ?>
										<div class="mpr-paint__meta"><?php if ( $mix ) : ?><span class="mpr-pill"><?php echo esc_html( $mix ); ?></span><?php endif; ?><?php if ( $notes ) : ?><span class="mpr-note"><?php echo esc_html( $notes ); ?></span><?php endif; ?></div>
									<?php endif; ?>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $grouped_steps ) ) : ?>
		<section class="mpr-card__section" id="mpr-steps-<?php echo esc_attr( (string) $post->ID ); ?>">
			<h3><?php esc_html_e( 'Steps', 'miniature-paint-recipes' ); ?></h3>
			<div class="mpr-step-groups" data-mpr-step-groups>
				<?php $visible_index = 1; ?>
				<?php foreach ( $grouped_steps as $group_label => $items ) : ?>
					<div class="mpr-step-group">
						<h4 class="mpr-step-group__title"><?php echo esc_html( $group_label ); ?></h4>
						<ol class="mpr-step-list">
							<?php foreach ( $items as $step ) : ?>
								<?php
								$title = trim( (string) ( $step['title'] ?? '' ) );
								$body  = trim( (string) ( $step['body'] ?? '' ) );
								$tech  = trim( (string) ( $step['techniques'] ?? '' ) );
								$time  = trim( (string) ( $step['time'] ?? '' ) );
								$legacy_paints = trim( (string) ( $step['paints'] ?? '' ) );
								$media_id = absint( (string) ( $step['media_id'] ?? '' ) );
								$img = $media_id ? wp_get_attachment_image( $media_id, 'medium_large', false, array( 'class' => 'mpr-step__img' ) ) : '';
								$linked_paints = array();
								foreach ( (array) ( $step['paints_used'] ?? array() ) as $pid ) {
									if ( isset( $paints_by_id[ $pid ] ) ) {
										$linked_paints[] = (string) ( $paints_by_id[ $pid ]['label'] ?? '' );
									}
								}
								?>
								<li class="mpr-step" id="mpr-step-<?php echo esc_attr( (string) $post->ID . '-' . (string) $visible_index ); ?>">
									<h5 class="mpr-step__title"><?php echo esc_html( $title !== '' ? $title : sprintf( __( 'Step %d', 'miniature-paint-recipes' ), $visible_index ) ); ?></h5>
									<?php if ( $img ) : ?><div class="mpr-step__media"><?php echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
									<?php if ( $body ) : ?><div class="mpr-step__body"><?php echo nl2br( esc_html( $body ) ); ?></div><?php endif; ?>
									<?php if ( ! empty( $linked_paints ) || $legacy_paints || $tech || $time ) : ?>
										<div class="mpr-step__meta">
											<?php foreach ( $linked_paints as $paint_label ) : ?><span class="mpr-pill"><?php echo esc_html( $paint_label ); ?></span><?php endforeach; ?>
											<?php if ( $legacy_paints ) : ?><span class="mpr-pill"><?php echo esc_html( $legacy_paints ); ?></span><?php endif; ?>
											<?php if ( $tech ) : ?><span class="mpr-pill"><?php echo esc_html( $tech ); ?></span><?php endif; ?>
											<?php if ( $time ) : ?><span class="mpr-pill"><?php echo esc_html( $time ); ?></span><?php endif; ?>
										</div>
									<?php endif; ?>
								</li>
								<?php $visible_index++; ?>
							<?php endforeach; ?>
						</ol>
					</div>
				<?php endforeach; ?>
			</div>
			<p class="mpr-backtotop"><a href="#mpr-top-<?php echo esc_attr( (string) $post->ID ); ?>"><?php esc_html_e( 'Back to top', 'miniature-paint-recipes' ); ?></a></p>
		</section>
	<?php endif; ?>

	<script type="application/ld+json"><?php echo wp_json_encode( $schema ); ?></script>
	<script>
	(function(){
		var card = document.currentScript.closest('.mpr-card');
		if (!card) return;
		var status = card.querySelector('.mpr-toolbar__status');
		var recipeId = card.getAttribute('data-mpr-recipe-id') || '0';
		var toggleButton = card.querySelector('.mpr-toggle-steps');
		var stepGroups = card.querySelector('[data-mpr-step-groups]');
		var storageKey = 'mpr-step-collapse-' + recipeId;
		function setStatus(msg){ if(status){ status.textContent = msg; setTimeout(function(){ if(status.textContent===msg){ status.textContent=''; } }, 1800); } }
		function copyText(text){
			if (navigator.clipboard && navigator.clipboard.writeText) { return navigator.clipboard.writeText(text); }
			return new Promise(function(resolve, reject){
				var el = document.createElement('textarea'); el.value = text; document.body.appendChild(el); el.select();
				try { document.execCommand('copy') ? resolve() : reject(); } catch(e){ reject(e); }
				document.body.removeChild(el);
			});
		}
		function updateCollapse(collapsed){
			if (!stepGroups || !toggleButton) return;
			stepGroups.style.display = collapsed ? 'none' : '';
			var back = card.querySelector('.mpr-backtotop'); if (back) back.style.display = collapsed ? 'none' : '';
			toggleButton.textContent = collapsed ? 'Expand steps' : 'Collapse steps';
			window.localStorage.setItem(storageKey, collapsed ? '1' : '0');
		}
		var collapsed = window.localStorage.getItem(storageKey) === '1';
		updateCollapse(collapsed);
		if (toggleButton) toggleButton.addEventListener('click', function(){ collapsed = !collapsed; updateCollapse(collapsed); });
		var shortBtn = card.querySelector('.mpr-copy-shortcode');
		if (shortBtn) shortBtn.addEventListener('click', function(){ copyText('[paint_recipe id="' + recipeId + '"]').then(function(){setStatus('Copied shortcode.');}).catch(function(){setStatus('Copy failed.');}); });
		var paintsText = <?php echo wp_json_encode( implode( "\n", array_map( static function( $row ) {
			$line = '';
			if ( ! empty( $row['role'] ) ) { $line .= $row['role'] . ': '; }
			$line .= $row['label'] ?? '';
			if ( ! empty( $row['mix'] ) ) { $line .= ' (' . $row['mix'] . ')'; }
			return trim( $line );
		}, array_values( $paints_by_id ) ) ) ); ?>;
		var stepsText = <?php
		$copy_steps = array();
		$i = 1;
		foreach ( $grouped_steps as $group_label => $items ) {
			$copy_steps[] = $group_label;
			foreach ( $items as $step ) {
				$copy_steps[] = $i . '. ' . trim( (string) ( $step['title'] ?? sprintf( 'Step %d', $i ) ) );
				$copy_steps[] = trim( (string) ( $step['body'] ?? '' ) );
				$copy_steps[] = '';
				$i++;
			}
		}
		echo wp_json_encode( implode( "\n", $copy_steps ) );
		?>;
		var paintsBtn = card.querySelector('.mpr-copy-paints');
		if (paintsBtn) paintsBtn.addEventListener('click', function(){ copyText(paintsText).then(function(){setStatus('Copied paints.');}).catch(function(){setStatus('Copy failed.');}); });
		var stepsBtn = card.querySelector('.mpr-copy-steps');
		if (stepsBtn) stepsBtn.addEventListener('click', function(){ copyText(stepsText).then(function(){setStatus('Copied steps.');}).catch(function(){setStatus('Copy failed.');}); });
		var calculators = card.querySelectorAll('[data-mpr-calculator]');
		calculators.forEach(function(calcEl){
			var config = {};
			try { config = JSON.parse(calcEl.getAttribute('data-mpr-calculator') || '{}'); } catch(e) { config = {}; }
			var input = calcEl.querySelector('.mpr-calculator__input');
			var list = calcEl.querySelector('.mpr-calculator__list');
			function convert(amount, unit){
				if(unit === 'drops'){
					if(amount >= 240){ return { value: Math.ceil((amount / 240) * 100) / 100, unit: '12 ml pot equivalents' }; }
					if(amount >= 20){ return { value: Math.ceil((amount / 20) * 100) / 100, unit: 'ml' }; }
					return { value: Math.ceil(amount * 100) / 100, unit: 'drops' };
				}
				return { value: Math.ceil(amount * 100) / 100, unit: unit };
			}
			function render(){
				var models = Number(input.value); if (!Number.isSafeInteger(models) || models < 1 || models > 100000) { list.textContent = 'Enter a whole number between 1 and 100,000.'; return; }
				var ratio = models / (config.batchSize || 1);
				list.innerHTML = '';
				(config.rows || []).forEach(function(row){
					var raw = (parseFloat(row.amount || 0) * ratio);
					if (!raw || raw <= 0) return;
					var display = convert(raw, row.unit || 'drops');
					var li = document.createElement('li');
					li.textContent = (row.role ? row.role + ': ' : '') + row.label + ' — ' + display.value + ' ' + display.unit;
					list.appendChild(li);
				});
			}
			if (input) { input.addEventListener('input', render); render(); }
		});
	})();
	</script>
</div>
