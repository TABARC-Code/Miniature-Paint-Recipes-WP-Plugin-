<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$meta_line  = trim( $subject . ( $subject && $scale ? ' | ' : '' ) . $scale );
$batch_size = (int) get_post_meta( $post->ID, \MiniaturePaintRecipes\MPR_Meta::META_BATCH_SIZE, true );
$profile    = (string) get_post_meta( $post->ID, \MiniaturePaintRecipes\MPR_Meta::META_PROFILE, true );
$profiles   = \MiniaturePaintRecipes\MPR_Meta::model_profiles();
if ( $batch_size <= 0 ) { $batch_size = 1; }
if ( ! isset( $profiles[ $profile ] ) ) { $profile = 'infantry'; }
$profile_cfg = $profiles[ $profile ];

$resolved = array();
foreach ( $paints as $p ) {
	if ( ! is_array( $p ) ) { continue; }
	$lib_id = absint( (string) ( $p['library_id'] ?? '' ) );
	if ( $lib_id > 0 && is_user_logged_in() ) {
		$pref = \MiniaturePaintRecipes\MPR_Paint_Library::get_preferred_brand_term_id( get_current_user_id() );
		if ( $pref > 0 ) {
			$eq_id = ( new \MiniaturePaintRecipes\MPR_Equivalents() )->resolve_preferred_equivalent( $lib_id, $pref );
			if ( $eq_id > 0 ) { $lib_id = $eq_id; }
		}
		$title = get_the_title( $lib_id );
		if ( $title ) { $p['name'] = $title; }
		$p['brand'] = implode( ', ', (array) wp_get_post_terms( $lib_id, \MiniaturePaintRecipes\MPR_Taxonomies::TAX_BRAND, array( 'fields' => 'names' ) ) );
		$p['range'] = implode( ', ', (array) wp_get_post_terms( $lib_id, \MiniaturePaintRecipes\MPR_Taxonomies::TAX_RANGE, array( 'fields' => 'names' ) ) );
	}
	$pid = (string) ( $p['id'] ?? '' );
	if ( $pid ) { $resolved[ $pid ] = $p; }
}
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( get_the_title( $post ) ); ?><?php echo $meta_line ? ' - ' . esc_html( $meta_line ) : ''; ?></title>
	<style>
		body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 24px; color: #111; }
		h1, h2, h3 { margin: 0 0 8px; }
		.meta { color: #555; margin-bottom: 16px; }
		hr { border: 0; border-top: 1px solid #ddd; margin: 18px 0; }
		.paints ul, .steps ol { padding-left: 18px; }
		.small { color: #666; font-size: 12px; }
		img { max-width: 100%; height: auto; }
	</style>
</head>
<body>
	<h1><?php echo esc_html( get_the_title( $post ) ); ?></h1>
	<?php if ( $meta_line ) : ?><div class="meta"><?php echo esc_html( $meta_line ); ?></div><?php endif; ?>
	<div class="small"><?php echo esc_html( sprintf( __( '%s profile ×%s · batch size %d', 'miniature-paint-recipes' ), $profile_cfg['label'], $profile_cfg['multiplier'], $batch_size ) ); ?></div>
	<div class="small"><?php esc_html_e( 'Printed from', 'miniature-paint-recipes' ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?> · <?php echo esc_html( get_permalink( $post ) ); ?></div>
	<hr>

	<?php if ( ! empty( $paints ) ) : ?>
	<section class="paints">
		<h2><?php esc_html_e( 'Paint stack', 'miniature-paint-recipes' ); ?></h2>
		<ul>
			<?php foreach ( $paints as $p ) : ?>
				<?php
				if ( ! is_array( $p ) ) { continue; }
				$role = trim( (string) ( $p['role'] ?? '' ) );
				$label = trim( implode( ' ', array_filter( array( (string) ( $p['brand'] ?? '' ), (string) ( $p['range'] ?? '' ), (string) ( $p['name'] ?? '' ) ) ) ) );
				$line = $role ? $role . ': ' . $label : $label;
				if ( ! empty( $p['mix'] ) ) { $line .= ' (' . (string) $p['mix'] . ')'; }
				if ( ! empty( $p['calc_amount'] ) ) { $line .= ' — ' . (string) $p['calc_amount'] . ' ' . (string) ( $p['calc_unit'] ?? 'drops' ) . '/model'; }
				?>
				<li><?php echo esc_html( $line ); ?></li>
			<?php endforeach; ?>
		</ul>
	</section>
	<hr>
	<?php endif; ?>

	<?php if ( ! empty( $steps ) ) : ?>
	<section class="steps">
		<h2><?php esc_html_e( 'Steps', 'miniature-paint-recipes' ); ?></h2>
		<ol>
			<?php foreach ( $steps as $idx => $s ) : ?>
				<?php
				if ( ! is_array( $s ) ) { continue; }
				$title = trim( (string) ( $s['title'] ?? '' ) );
				$body  = trim( (string) ( $s['body'] ?? '' ) );
				if ( '' === $title && '' === $body ) { continue; }
				$media_id = absint( (string) ( $s['media_id'] ?? '' ) );
				$img = $media_id ? wp_get_attachment_image( $media_id, 'large', false ) : '';
				$linked = array();
				foreach ( (array) ( $s['paints_used'] ?? array() ) as $pid ) {
					if ( isset( $resolved[ $pid ] ) ) {
						$linked[] = trim( implode( ' ', array_filter( array( (string) ( $resolved[ $pid ]['brand'] ?? '' ), (string) ( $resolved[ $pid ]['name'] ?? '' ) ) ) ) );
					}
				}
				?>
				<li>
					<strong><?php echo esc_html( $title !== '' ? $title : sprintf( 'Step %d', (int) $idx + 1 ) ); ?></strong><br>
					<?php if ( ! empty( $s['group'] ) ) : ?><em><?php echo esc_html( (string) $s['group'] ); ?></em><br><?php endif; ?>
					<?php if ( $img ) : ?><div style="margin:8px 0;"><?php echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
					<?php echo nl2br( esc_html( $body ) ); ?>
					<?php if ( ! empty( $linked ) ) : ?><div><small><?php echo esc_html( implode( ', ', $linked ) ); ?></small></div><?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</section>
	<?php endif; ?>

	<script type="application/ld+json"><?php echo wp_json_encode( $schema ); ?></script>
</body>
</html>
