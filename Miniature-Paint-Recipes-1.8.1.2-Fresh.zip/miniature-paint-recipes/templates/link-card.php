<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Link card shown in blog posts. Variables from MPR_Renderer::link_card_shortcode():
 * $post, $subject, $scale, $swatches, $paint_count, $step_count, $minutes, $excerpt, $image_html, $button_text, $locked.
 */
$meta_line = trim( $subject . ( $subject && $scale ? ' | ' : '' ) . $scale );
$facts     = array();
if ( ! $locked ) {
	if ( $paint_count > 0 ) { $facts[] = sprintf( _n( '%d paint', '%d paints', $paint_count, 'miniature-paint-recipes' ), $paint_count ); }
	if ( $step_count > 0 ) { $facts[] = sprintf( _n( '%d step', '%d steps', $step_count, 'miniature-paint-recipes' ), $step_count ); }
	if ( $minutes > 0 ) {
		$facts[] = sprintf( __( 'about %s', 'miniature-paint-recipes' ), ( intdiv( $minutes, 60 ) ? intdiv( $minutes, 60 ) . 'h ' : '' ) . ( $minutes % 60 ? ( $minutes % 60 ) . 'm' : '' ) );
	}
}
?>
<article class="mpr-link-card<?php echo $image_html ? ' mpr-link-card--has-image' : ''; ?>">
	<?php if ( $image_html ) : ?>
		<div class="mpr-link-card__media"><?php echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	<?php endif; ?>
	<div class="mpr-link-card__body">
		<p class="mpr-link-card__eyebrow"><?php esc_html_e( 'Paint recipe', 'miniature-paint-recipes' ); ?></p>
		<h3 class="mpr-link-card__title"><a href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></h3>
		<?php if ( $meta_line ) : ?><p class="mpr-link-card__meta"><?php echo esc_html( $meta_line ); ?></p><?php endif; ?>
		<?php if ( ! empty( $swatches ) ) : ?>
			<div class="mpr-link-card__swatches" aria-hidden="true">
				<?php foreach ( $swatches as $hex ) : ?><span class="mpr-link-card__swatch" style="background: <?php echo esc_attr( $hex ); ?>"></span><?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $facts ) ) : ?><p class="mpr-link-card__facts"><?php echo esc_html( implode( ' · ', $facts ) ); ?></p><?php endif; ?>
		<?php if ( $excerpt ) : ?><p class="mpr-link-card__excerpt"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
		<span class="mpr-link-card__cta" aria-hidden="true"><?php echo esc_html( $button_text ); ?> &rarr;</span>
	</div>
</article>
